package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "voice_commands")
data class VoiceCommandEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val commandText: String,
    val interpretedIntent: String,
    val status: String, // SUCCESS, FAILED, CONFIRMED, CANCELLED
    val responseSpoken: String,
    val speakerVerified: Boolean = false,
    val speakerName: String = "Authorized User",
    val timestamp: Long = System.currentTimeMillis(),
    val operatingMode: String = "STANDARD",
    val language: String = "en"
)
