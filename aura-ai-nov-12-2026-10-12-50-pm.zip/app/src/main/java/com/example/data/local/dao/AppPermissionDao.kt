package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.AppPermissionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AppPermissionDao {
    @Query("SELECT * FROM app_permissions ORDER BY id ASC")
    fun getAllPermissions(): Flow<List<AppPermissionEntity>>

    @Query("SELECT * FROM app_permissions WHERE id = :id LIMIT 1")
    suspend fun getPermissionById(id: String): AppPermissionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPermissions(permissions: List<AppPermissionEntity>)

    @Update
    suspend fun updatePermission(permission: AppPermissionEntity)

    @Query("UPDATE app_permissions SET preference = :pref, status = :status, lastAccessedTimestamp = :time WHERE id = :id")
    suspend fun updatePermissionPreference(id: String, pref: String, status: String, time: Long)

    @Query("UPDATE app_permissions SET status = 'REVOKED', preference = 'DENY' WHERE id = :id")
    suspend fun revokePermission(id: String)
}
