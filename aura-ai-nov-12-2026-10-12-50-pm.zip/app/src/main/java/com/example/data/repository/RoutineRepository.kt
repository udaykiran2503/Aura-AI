package com.example.data.repository

import com.example.core.model.Routine
import com.example.core.model.RoutineStep
import com.example.core.model.RoutineStepType
import com.example.data.local.dao.RoutineDao
import com.example.data.local.entity.RoutineEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class RoutineRepository(private val routineDao: RoutineDao) {

    val allRoutines: Flow<List<Routine>> = routineDao.getAllRoutines().map { entities ->
        entities.map { it.toDomain() }
    }

    val activeRoutines: Flow<List<Routine>> = routineDao.getActiveRoutines().map { entities ->
        entities.map { it.toDomain() }
    }

    suspend fun getRoutineById(id: String): Routine? {
        return routineDao.getRoutineById(id)?.toDomain()
    }

    suspend fun findRoutineByTrigger(command: String): Routine? {
        val normalized = command.trim().lowercase()
        val active = routineDao.getActiveRoutinesSync()
        return active.firstOrNull { entity ->
            val trigger = entity.triggerPhrase.trim().lowercase()
            normalized.contains(trigger) || trigger.contains(normalized)
        }?.toDomain()
    }

    suspend fun createRoutine(
        name: String,
        triggerPhrase: String,
        description: String,
        iconName: String,
        steps: List<RoutineStep>
    ): Routine {
        val newRoutine = Routine(
            id = "custom_" + UUID.randomUUID().toString().take(8),
            name = name.trim(),
            triggerPhrase = triggerPhrase.trim().lowercase(),
            description = description.trim(),
            iconName = iconName,
            isEnabled = true,
            isCustom = true,
            steps = steps,
            createdAt = System.currentTimeMillis()
        )
        routineDao.insertRoutine(newRoutine.toEntity())
        return newRoutine
    }

    suspend fun updateRoutine(routine: Routine) {
        routineDao.updateRoutine(routine.toEntity())
    }

    suspend fun toggleRoutinePause(id: String, isEnabled: Boolean) {
        routineDao.setRoutineEnabled(id, isEnabled)
    }

    suspend fun updateLastExecuted(id: String) {
        routineDao.updateLastExecuted(id, System.currentTimeMillis())
    }

    suspend fun deleteRoutine(id: String) {
        routineDao.deleteRoutineById(id)
    }

    suspend fun ensureDefaultRoutines() {
        if (routineDao.getCount() == 0) {
            val defaults = listOf(
                Routine(
                    id = "good_morning",
                    name = "Good Morning",
                    triggerPhrase = "good morning",
                    description = "Announces current time, weather forecast, today's schedule, and sets comfortable volume",
                    iconName = "wb_sunny",
                    isEnabled = true,
                    isCustom = false,
                    steps = listOf(
                        RoutineStep("step_gm_1", RoutineStepType.ANNOUNCE_TIME, "Announce Time & Date"),
                        RoutineStep("step_gm_2", RoutineStepType.ANNOUNCE_WEATHER, "Check Weather Forecast", "Local Area"),
                        RoutineStep("step_gm_3", RoutineStepType.ANNOUNCE_SCHEDULE, "Summarize Today's Reminders & Agenda"),
                        RoutineStep("step_gm_4", RoutineStepType.SET_VOLUME, "Set Media Volume to 70%", "70"),
                        RoutineStep("step_gm_5", RoutineStepType.SPEAK_TEXT, "Daily Greeting", "Have a wonderful and productive day!")
                    )
                ),
                Routine(
                    id = "bedtime",
                    name = "Bedtime Routine",
                    triggerPhrase = "bedtime",
                    description = "Dims phone, mutes loud sounds, checks tomorrow's alarms, and ensures quiet night",
                    iconName = "bedtime",
                    isEnabled = true,
                    isCustom = false,
                    steps = listOf(
                        RoutineStep("step_bt_1", RoutineStepType.TOGGLE_FLASHLIGHT, "Ensure Flashlight is Off", "false"),
                        RoutineStep("step_bt_2", RoutineStepType.SET_VOLUME, "Lower Volume to 15%", "15"),
                        RoutineStep("step_bt_3", RoutineStepType.SET_BRIGHTNESS, "Dim Screen Brightness to 15%", "15"),
                        RoutineStep("step_bt_4", RoutineStepType.SPEAK_TEXT, "Bedtime Wishes", "Good night. All scheduled alarms remain active for tomorrow.")
                    )
                ),
                Routine(
                    id = "driving_mode",
                    name = "Driving Mode",
                    triggerPhrase = "driving mode",
                    description = "Sets high speaker volume, opens navigation map, and keeps hands-free voice ready",
                    iconName = "directions_car",
                    isEnabled = true,
                    isCustom = false,
                    steps = listOf(
                        RoutineStep("step_drv_1", RoutineStepType.SET_VOLUME, "Increase Volume to 90%", "90"),
                        RoutineStep("step_drv_2", RoutineStepType.LAUNCH_APP, "Launch Google Maps", "com.google.android.apps.maps"),
                        RoutineStep("step_drv_3", RoutineStepType.SPEAK_TEXT, "Safety Announcement", "Driving mode activated. Hands-free voice recognition is standby.")
                    )
                ),
                Routine(
                    id = "workout_mode",
                    name = "Workout Mode",
                    triggerPhrase = "workout mode",
                    description = "Prepares phone for exercise with energetic volume and battery health check",
                    iconName = "fitness_center",
                    isEnabled = true,
                    isCustom = false,
                    steps = listOf(
                        RoutineStep("step_wk_1", RoutineStepType.SET_VOLUME, "Boost Audio Volume to 85%", "85"),
                        RoutineStep("step_wk_2", RoutineStepType.CHECK_BATTERY, "Check Battery Charge Level"),
                        RoutineStep("step_wk_3", RoutineStepType.SPEAK_TEXT, "Workout Motivation", "Workout session initiated. Stay hydrated and let's crush your goals.")
                    )
                ),
                Routine(
                    id = "emergency_alert",
                    name = "Emergency Assistance",
                    triggerPhrase = "emergency assistance",
                    description = "Sounds siren alarm tone and activates strobe flashlight for emergency alert",
                    iconName = "emergency",
                    isEnabled = true,
                    isCustom = false,
                    steps = listOf(
                        RoutineStep("step_em_1", RoutineStepType.FIND_PHONE_ALERT, "Sound Audible Siren Alert"),
                        RoutineStep("step_em_2", RoutineStepType.TOGGLE_FLASHLIGHT, "Turn On Emergency Flashlight", "true"),
                        RoutineStep("step_em_3", RoutineStepType.SPEAK_TEXT, "Emergency Alert", "Emergency routine triggered. Standby for assistance.")
                    )
                )
            )
            routineDao.insertRoutines(defaults.map { it.toEntity() })
        }
    }
}

// Entity <-> Domain mappers with JSON serialization
fun Routine.toEntity(): RoutineEntity {
    val jsonArray = JSONArray()
    for (step in steps) {
        val obj = JSONObject()
        obj.put("id", step.id)
        obj.put("type", step.type.name)
        obj.put("label", step.label)
        obj.put("parameter", step.parameter)
        jsonArray.put(obj)
    }
    return RoutineEntity(
        id = id,
        name = name,
        triggerPhrase = triggerPhrase,
        description = description,
        iconName = iconName,
        isEnabled = isEnabled,
        isCustom = isCustom,
        stepsJson = jsonArray.toString(),
        createdAt = createdAt,
        lastExecutedAt = lastExecutedAt
    )
}

fun RoutineEntity.toDomain(): Routine {
    val stepsList = mutableListOf<RoutineStep>()
    try {
        val jsonArray = JSONArray(stepsJson)
        for (i in 0 until jsonArray.length()) {
            val obj = jsonArray.getJSONObject(i)
            val typeStr = obj.optString("type", RoutineStepType.SPEAK_TEXT.name)
            val type = try {
                RoutineStepType.valueOf(typeStr)
            } catch (e: Exception) {
                RoutineStepType.SPEAK_TEXT
            }
            stepsList.add(
                RoutineStep(
                    id = obj.optString("id", "step_$i"),
                    type = type,
                    label = obj.optString("label", ""),
                    parameter = obj.optString("parameter", "")
                )
            )
        }
    } catch (e: Exception) {
        // fallback
    }
    return Routine(
        id = id,
        name = name,
        triggerPhrase = triggerPhrase,
        description = description,
        iconName = iconName,
        isEnabled = isEnabled,
        isCustom = isCustom,
        steps = stepsList,
        createdAt = createdAt,
        lastExecutedAt = lastExecutedAt
    )
}
