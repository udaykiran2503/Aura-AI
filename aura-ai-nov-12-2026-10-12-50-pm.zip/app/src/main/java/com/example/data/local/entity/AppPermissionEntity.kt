package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "app_permissions")
data class AppPermissionEntity(
    @PrimaryKey val id: String, // e.g., "RECORD_AUDIO", "CALL_PHONE", "SEND_SMS", "CAMERA_TORCH", "ACCESSIBILITY", "SETTINGS_WRITE"
    val featureName: String,
    val description: String,
    val requiredFor: String,
    val status: String, // GRANTED, DENIED, NOT_REQUESTED
    val preference: String, // ALLOW_FUTURE, ALLOW_SESSION, ALLOW_ONCE, DENY
    val lastAccessedTimestamp: Long = System.currentTimeMillis()
)
