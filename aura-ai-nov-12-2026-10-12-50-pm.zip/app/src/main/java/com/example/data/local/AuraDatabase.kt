package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.AppPermissionDao
import com.example.data.local.dao.RoutineDao
import com.example.data.local.dao.SecurityLogDao
import com.example.data.local.dao.UserPreferenceDao
import com.example.data.local.dao.VoiceCommandDao
import com.example.data.local.dao.VoiceProfileDao
import com.example.data.local.entity.AppPermissionEntity
import com.example.data.local.entity.RoutineEntity
import com.example.data.local.entity.SecurityLogEntity
import com.example.data.local.entity.UserPreferenceEntity
import com.example.data.local.entity.VoiceCommandEntity
import com.example.data.local.entity.VoiceProfileEntity

@Database(
    entities = [
        RoutineEntity::class,
        VoiceProfileEntity::class,
        VoiceCommandEntity::class,
        AppPermissionEntity::class,
        SecurityLogEntity::class,
        UserPreferenceEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AuraDatabase : RoomDatabase() {
    abstract fun routineDao(): RoutineDao
    abstract fun voiceProfileDao(): VoiceProfileDao
    abstract fun voiceCommandDao(): VoiceCommandDao
    abstract fun appPermissionDao(): AppPermissionDao
    abstract fun securityLogDao(): SecurityLogDao
    abstract fun userPreferenceDao(): UserPreferenceDao

    companion object {
        @Volatile
        private var INSTANCE: AuraDatabase? = null

        fun getInstance(context: Context): AuraDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AuraDatabase::class.java,
                    "aura_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
