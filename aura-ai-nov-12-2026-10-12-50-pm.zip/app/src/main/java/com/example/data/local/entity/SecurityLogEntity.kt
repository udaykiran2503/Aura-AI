package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "security_logs")
data class SecurityLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val eventType: String, // VOICE_AUTH, DEVICE_AUTH, SENSITIVE_CONFIRMATION, EMERGENCY_STOP, PRIVACY_TOGGLE, PERMISSION_CHANGED
    val title: String,
    val details: String,
    val riskLevel: String = "INFO", // INFO, WARNING, CRITICAL
    val timestamp: Long = System.currentTimeMillis()
)
