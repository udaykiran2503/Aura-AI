package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "voice_profiles")
data class VoiceProfileEntity(
    @PrimaryKey val id: String,
    val userName: String,
    val enrolledTimestamp: Long = System.currentTimeMillis(),
    val sampleCount: Int = 3,
    val averagePitchHz: Float = 145.0f,
    val energyVariance: Float = 0.28f,
    val cadenceEnvelope: String = "0.42,0.85,0.63,0.91",
    val confidenceThreshold: Float = 0.78f,
    val isPrimary: Boolean = true,
    val requireDeviceAuthForSensitive: Boolean = true
)
