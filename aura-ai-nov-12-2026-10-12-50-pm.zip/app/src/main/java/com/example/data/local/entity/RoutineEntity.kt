package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "routines")
data class RoutineEntity(
    @PrimaryKey val id: String,
    val name: String,
    val triggerPhrase: String,
    val description: String,
    val iconName: String,
    val isEnabled: Boolean = true,
    val isCustom: Boolean = false,
    val stepsJson: String, // JSON array of RoutineStep
    val createdAt: Long = System.currentTimeMillis(),
    val lastExecutedAt: Long? = null
)
