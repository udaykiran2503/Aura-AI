package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.VoiceProfileEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface VoiceProfileDao {
    @Query("SELECT * FROM voice_profiles ORDER BY enrolledTimestamp DESC")
    fun getAllVoiceProfiles(): Flow<List<VoiceProfileEntity>>

    @Query("SELECT * FROM voice_profiles WHERE isPrimary = 1 LIMIT 1")
    fun getPrimaryProfileFlow(): Flow<VoiceProfileEntity?>

    @Query("SELECT * FROM voice_profiles WHERE isPrimary = 1 LIMIT 1")
    suspend fun getPrimaryProfile(): VoiceProfileEntity?

    @Query("SELECT * FROM voice_profiles WHERE id = :id LIMIT 1")
    suspend fun getProfileById(id: String): VoiceProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: VoiceProfileEntity)

    @Update
    suspend fun updateProfile(profile: VoiceProfileEntity)

    @Query("UPDATE voice_profiles SET requireDeviceAuthForSensitive = :requireAuth WHERE id = :id")
    suspend fun setRequireDeviceAuth(id: String, requireAuth: Boolean)

    @Query("DELETE FROM voice_profiles WHERE id = :id")
    suspend fun deleteProfile(id: String)

    @Query("DELETE FROM voice_profiles")
    suspend fun clearAllProfiles()
}
