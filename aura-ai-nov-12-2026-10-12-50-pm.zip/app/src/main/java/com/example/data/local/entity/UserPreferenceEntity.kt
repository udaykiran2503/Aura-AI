package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_preferences")
data class UserPreferenceEntity(
    @PrimaryKey val prefKey: String,
    val prefValue: String,
    val lastUpdated: Long = System.currentTimeMillis()
)
