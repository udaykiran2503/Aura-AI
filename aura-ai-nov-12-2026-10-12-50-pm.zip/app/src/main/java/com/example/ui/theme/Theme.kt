package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = AuraCyan,
    onPrimary = Color(0xFF00363A),
    primaryContainer = Color(0xFF004F55),
    onPrimaryContainer = Color(0xFF9CF1FA),
    secondary = AuraVioletGlow,
    onSecondary = Color(0xFF38006B),
    secondaryContainer = Color(0xFF5A189A),
    onSecondaryContainer = Color(0xFFE0AAFF),
    tertiary = AuraMagenta,
    onTertiary = Color.White,
    background = AuraDeepBg,
    onBackground = AuraTextPrimary,
    surface = AuraSurface,
    onSurface = AuraTextPrimary,
    surfaceVariant = AuraSurfaceElevated,
    onSurfaceVariant = AuraTextSecondary,
    outline = AuraBorder,
    error = AuraRed,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = AuraLightPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFBAF0F6),
    onPrimaryContainer = Color(0xFF002023),
    secondary = AuraLightSecondary,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFEAD8F7),
    onSecondaryContainer = Color(0xFF280047),
    tertiary = Color(0xFFB5179E),
    onTertiary = Color.White,
    background = AuraLightBg,
    onBackground = Color(0xFF0F172A),
    surface = AuraLightSurface,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = AuraLightSurfaceElevated,
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFCBD5E1),
    error = Color(0xFFBA1A1A),
    onError = Color.White
)

@Composable
fun AuraTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
