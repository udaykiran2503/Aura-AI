package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.AuraApplication
import com.example.core.hardware.CapabilityItem
import com.example.core.hardware.DeviceSpecs
import com.example.core.hardware.OperatingMode
import com.example.core.model.Routine
import com.example.core.model.RoutineStep
import com.example.core.routine.RoutineExecutionState
import com.example.core.voice.AssistantVoiceState
import com.example.core.voice.VoiceMatchResult
import com.example.core.voice.VoiceProfile
import com.example.data.local.entity.AppPermissionEntity
import com.example.data.local.entity.SecurityLogEntity
import com.example.data.local.entity.VoiceCommandEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AuraViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as AuraApplication

    val voiceState: StateFlow<AssistantVoiceState> = app.voiceManager.voiceState
    val audioRms: StateFlow<Float> = app.voiceManager.audioRms
    val currentLanguage: StateFlow<String> = app.voiceManager.currentLanguage

    val allRoutines: StateFlow<List<Routine>> = app.routineRepository.allRoutines.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val routineExecutionState: StateFlow<RoutineExecutionState> = app.actionPlanner.routineState
    val lastExecutionSummary: StateFlow<String> = app.actionPlanner.lastExecutionSummary

    val primaryVoiceProfile: StateFlow<VoiceProfile?> = app.voiceProfileManager.primaryProfileFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    val recentCommands: StateFlow<List<VoiceCommandEntity>> = app.database.voiceCommandDao().getRecentCommands(25).stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val permissionsList: StateFlow<List<AppPermissionEntity>> = app.database.appPermissionDao().getAllPermissions().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val securityLogs: StateFlow<List<SecurityLogEntity>> = app.database.securityLogDao().getRecentLogs(30).stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val isPrivacyModeActive: StateFlow<Boolean> = app.safetyController.isPrivacyModeActive

    private val _operatingMode = MutableStateFlow(OperatingMode.STANDARD)
    val operatingMode: StateFlow<OperatingMode> = _operatingMode.asStateFlow()

    private val _deviceSpecs = MutableStateFlow<DeviceSpecs?>(null)
    val deviceSpecs: StateFlow<DeviceSpecs?> = _deviceSpecs.asStateFlow()

    private val _capabilitiesMatrix = MutableStateFlow<List<CapabilityItem>>(emptyList())
    val capabilitiesMatrix: StateFlow<List<CapabilityItem>> = _capabilitiesMatrix.asStateFlow()

    // Voice profile enrollment state
    private val _enrollmentStep = MutableStateFlow(0) // 0: not enrolling, 1, 2, 3
    val enrollmentStep: StateFlow<Int> = _enrollmentStep.asStateFlow()

    private val _enrollmentSamples = mutableListOf<Float>()

    private val _lastVerificationResult = MutableStateFlow<VoiceMatchResult?>(null)
    val lastVerificationResult: StateFlow<VoiceMatchResult?> = _lastVerificationResult.asStateFlow()

    init {
        refreshHardwareDiagnostics()
    }

    fun refreshHardwareDiagnostics() {
        val specs = app.deviceCompatibilityManager.getDeviceSpecs()
        _deviceSpecs.value = specs
        _operatingMode.value = specs.recommendedMode
        _capabilitiesMatrix.value = app.deviceCompatibilityManager.getCapabilitiesMatrix()
    }

    fun setOperatingMode(mode: OperatingMode) {
        _operatingMode.value = mode
    }

    fun toggleVoiceListening() {
        if (voiceState.value == AssistantVoiceState.LISTENING) {
            app.voiceManager.stopListening()
        } else {
            app.voiceManager.startListening()
        }
    }

    fun emergencyStop() {
        viewModelScope.launch {
            app.voiceManager.emergencyStop()
            app.deviceController.triggerFindPhoneAlert(false)
            app.safetyController.logEmergencyStop()
        }
    }

    fun togglePrivacyMode() {
        val current = isPrivacyModeActive.value
        app.safetyController.togglePrivacyMode(!current)
        if (!current) {
            app.voiceManager.emergencyStop()
        }
    }

    fun setLanguage(langCode: String) {
        app.voiceManager.setLanguage(langCode)
    }

    // --- Routine Management ---
    fun runRoutine(routine: Routine) {
        viewModelScope.launch {
            app.actionPlanner.planAndExecute(
                com.example.core.engine.ParsedIntent(
                    rawText = "Trigger routine: ${routine.name}",
                    intentName = "EXECUTE_ROUTINE",
                    action = com.example.core.engine.AuraAction.ExecuteRoutine(routine.id, routine.name)
                ),
                operatingMode = _operatingMode.value.name
            )
        }
    }

    fun toggleRoutinePause(routineId: String, currentEnabled: Boolean) {
        viewModelScope.launch {
            app.routineRepository.toggleRoutinePause(routineId, !currentEnabled)
        }
    }

    fun deleteRoutine(routineId: String) {
        viewModelScope.launch {
            app.routineRepository.deleteRoutine(routineId)
        }
    }

    fun createCustomRoutine(
        name: String,
        triggerPhrase: String,
        description: String,
        iconName: String,
        steps: List<RoutineStep>
    ) {
        viewModelScope.launch {
            app.routineRepository.createRoutine(
                name = name,
                triggerPhrase = triggerPhrase,
                description = description,
                iconName = iconName,
                steps = steps
            )
        }
    }

    fun updateRoutine(routine: Routine) {
        viewModelScope.launch {
            app.routineRepository.updateRoutine(routine)
        }
    }

    // --- Voice Profile Management ---
    fun startEnrollment() {
        _enrollmentSamples.clear()
        _enrollmentStep.value = 1
    }

    fun recordEnrollmentSample(pitchHz: Float = 145f) {
        _enrollmentSamples.add(pitchHz)
        if (_enrollmentStep.value < 3) {
            _enrollmentStep.value = _enrollmentStep.value + 1
        } else {
            // Completed 3 samples
            finishEnrollment("Authorized User")
        }
    }

    fun cancelEnrollment() {
        _enrollmentSamples.clear()
        _enrollmentStep.value = 0
    }

    private fun finishEnrollment(userName: String) {
        viewModelScope.launch {
            app.voiceProfileManager.enrollVoiceProfile(
                userName = userName,
                samplePitchList = _enrollmentSamples.toList(),
                sampleCadences = listOf(0.42f, 0.88f, 0.65f),
                requireDeviceAuth = true
            )
            _enrollmentStep.value = 0
            _enrollmentSamples.clear()
        }
    }

    fun testVoiceVerification(simulatedPitchHz: Float = 145f) {
        viewModelScope.launch {
            val result = app.voiceProfileManager.verifyVoice(observedPitchHz = simulatedPitchHz)
            _lastVerificationResult.value = result
        }
    }

    fun setRequireDeviceAuthForSensitive(requireAuth: Boolean) {
        viewModelScope.launch {
            app.voiceProfileManager.setRequireDeviceAuth(requireAuth)
        }
    }

    fun resetVoiceProfile() {
        viewModelScope.launch {
            app.voiceProfileManager.resetProfile()
            _lastVerificationResult.value = null
        }
    }

    // --- Manual text command invocation ---
    fun sendTextCommand(commandText: String) {
        if (commandText.isBlank()) return
        viewModelScope.launch {
            val parsed = app.intentParser.parse(commandText)
            app.actionPlanner.planAndExecute(parsed, operatingMode = _operatingMode.value.name)
        }
    }
}
