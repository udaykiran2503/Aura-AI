package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.hardware.OperatingMode
import com.example.core.voice.AssistantVoiceState
import com.example.ui.AuraViewModel
import com.example.ui.components.AuraOrb
import com.example.ui.theme.AuraAmber
import com.example.ui.theme.AuraBorder
import com.example.ui.theme.AuraCyan
import com.example.ui.theme.AuraEmerald
import com.example.ui.theme.AuraRed
import com.example.ui.theme.AuraSurface
import com.example.ui.theme.AuraSurfaceElevated
import com.example.ui.theme.AuraTextMuted
import com.example.ui.theme.AuraTextPrimary
import com.example.ui.theme.AuraTextSecondary
import com.example.ui.theme.AuraVioletGlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DashboardScreen(
    viewModel: AuraViewModel,
    onNavigateToRoutines: () -> Unit,
    modifier: Modifier = Modifier
) {
    val voiceState by viewModel.voiceState.collectAsStateWithLifecycle()
    val audioRms by viewModel.audioRms.collectAsStateWithLifecycle()
    val operatingMode by viewModel.operatingMode.collectAsStateWithLifecycle()
    val currentLang by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val isPrivacyActive by viewModel.isPrivacyModeActive.collectAsStateWithLifecycle()
    val executionState by viewModel.routineExecutionState.collectAsStateWithLifecycle()
    val lastSummary by viewModel.lastExecutionSummary.collectAsStateWithLifecycle()
    val recentCommands by viewModel.recentCommands.collectAsStateWithLifecycle()
    val routines by viewModel.allRoutines.collectAsStateWithLifecycle()

    var showLangMenu by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            // Top Controls Bar (Operating Mode pill, Language selector, Privacy shield)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Operating Mode Badge
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = AuraSurfaceElevated,
                    modifier = Modifier.border(1.dp, AuraBorder, RoundedCornerShape(12.dp))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = null,
                            tint = when (operatingMode) {
                                OperatingMode.LIGHT -> AuraAmber
                                OperatingMode.STANDARD -> AuraCyan
                                OperatingMode.ADVANCED -> AuraVioletGlow
                            },
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = operatingMode.title,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = AuraTextPrimary
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Language Switcher
                    Box {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = AuraSurfaceElevated,
                            modifier = Modifier
                                .border(1.dp, AuraBorder, RoundedCornerShape(12.dp))
                                .clickable { showLangMenu = true }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Language,
                                    contentDescription = "Language",
                                    tint = AuraCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = currentLang.uppercase(),
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = AuraCyan
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = showLangMenu,
                            onDismissRequest = { showLangMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("English (US/IN)") },
                                onClick = {
                                    viewModel.setLanguage("en")
                                    showLangMenu = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("తెలుగు (Telugu)") },
                                onClick = {
                                    viewModel.setLanguage("te")
                                    showLangMenu = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("हिंदी (Hindi)") },
                                onClick = {
                                    viewModel.setLanguage("hi")
                                    showLangMenu = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("தமிழ் (Tamil)") },
                                onClick = {
                                    viewModel.setLanguage("ta")
                                    showLangMenu = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("ಕನ್ನಡ (Kannada)") },
                                onClick = {
                                    viewModel.setLanguage("kn")
                                    showLangMenu = false
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Privacy Shield Toggle
                    IconButton(
                        onClick = { viewModel.togglePrivacyMode() },
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(if (isPrivacyActive) AuraRed.copy(alpha = 0.2f) else AuraSurfaceElevated)
                            .border(
                                1.dp,
                                if (isPrivacyActive) AuraRed else AuraBorder,
                                CircleShape
                            )
                            .testTag("privacy_mode_button")
                    ) {
                        Icon(
                            imageVector = if (isPrivacyActive) Icons.Default.MicOff else Icons.Default.Shield,
                            contentDescription = "Privacy Shield",
                            tint = if (isPrivacyActive) AuraRed else AuraCyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        // Central Orb & Voice Activation State
        item {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(vertical = 12.dp)
            ) {
                AuraOrb(
                    voiceState = voiceState,
                    audioRms = audioRms,
                    size = 190.dp,
                    onClick = { viewModel.toggleVoiceListening() }
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Status text
                Text(
                    text = when (voiceState) {
                        AssistantVoiceState.IDLE -> if (isPrivacyActive) "Privacy Mode: Mic Disabled" else "Tap Orb or Say \"Hey Aura\""
                        AssistantVoiceState.LISTENING -> "Listening to your voice…"
                        AssistantVoiceState.PROCESSING -> "Analyzing intent & planning action…"
                        AssistantVoiceState.SPEAKING -> "Speaking response…"
                        AssistantVoiceState.ERROR -> "Microphone issue. Tap to retry."
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = when (voiceState) {
                        AssistantVoiceState.LISTENING -> AuraCyan
                        AssistantVoiceState.PROCESSING -> AuraVioletGlow
                        AssistantVoiceState.SPEAKING -> AuraEmerald
                        AssistantVoiceState.ERROR -> AuraRed
                        else -> if (isPrivacyActive) AuraRed else AuraTextPrimary
                    }
                )

                if (lastSummary.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = lastSummary,
                        style = MaterialTheme.typography.bodySmall,
                        color = AuraTextSecondary
                    )
                }
            }
        }

        // Live Routine Execution Progress Banner (if active)
        if (executionState.isRunning || executionState.currentStepLabel == "Completed") {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF00383D)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, AuraCyan, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = AuraCyan)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = executionState.routineName,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                            Text(
                                text = "Step ${executionState.currentStepIndex}/${executionState.totalSteps}",
                                color = AuraCyan,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = executionState.currentStepLabel,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFC7F9FF)
                        )
                    }
                }
            }
        }

        // Featured Smart Routine Hero Card ("Good Morning Routine")
        item {
            val goodMorningRoutine = routines.firstOrNull { it.id == "good_morning" }
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = AuraSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AuraCyan.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                    .testTag("featured_good_morning_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(AuraAmber.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.WbSunny,
                                    contentDescription = null,
                                    tint = AuraAmber,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Good Morning Routine",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = AuraTextPrimary
                                )
                                Text(
                                    text = "Announces time, weather & today's schedule",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = AuraTextSecondary
                                )
                            }
                        }

                        Button(
                            onClick = {
                                goodMorningRoutine?.let { viewModel.runRoutine(it) }
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = AuraCyan),
                            modifier = Modifier.testTag("run_good_morning_button")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFF00363A))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Run", color = Color(0xFF00363A), fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = AuraSurfaceElevated,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Say: \"Hey Aura, good morning\" to execute all 5 steps hands-free.",
                            style = MaterialTheme.typography.labelSmall,
                            color = AuraCyan,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // Quick Voice Commands Flow
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Quick Voice Commands",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = AuraTextPrimary
                    )
                    Text(
                        text = "View Routines →",
                        style = MaterialTheme.typography.labelMedium,
                        color = AuraCyan,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { onNavigateToRoutines() }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val commands = listOf(
                        "Good Morning Routine",
                        "Turn on flashlight",
                        "What time is it?",
                        "Check my battery",
                        "Find my phone",
                        "Bedtime routine",
                        "Driving mode",
                        "Open WhatsApp"
                    )
                    commands.forEach { cmd ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = AuraSurfaceElevated,
                            modifier = Modifier
                                .border(1.dp, AuraBorder, RoundedCornerShape(10.dp))
                                .clickable { viewModel.sendTextCommand(cmd) }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = null,
                                    tint = AuraCyan,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = cmd,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AuraTextPrimary,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        }

        // Emergency Stop Control Button
        item {
            Button(
                onClick = { viewModel.emergencyStop() },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AuraRed),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("emergency_stop_button")
            ) {
                Icon(
                    imageVector = Icons.Default.StopCircle,
                    contentDescription = "Stop",
                    tint = Color.White
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Emergency Stop (Cancel All Actions)",
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }

        // Recent Activity History
        item {
            Text(
                text = "Recent Command Logs",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = AuraTextPrimary,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            )
        }

        if (recentCommands.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = AuraSurface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, AuraBorder, RoundedCornerShape(12.dp))
                        .padding(20.dp)
                ) {
                    Text(
                        text = "No recent voice commands. Tap the Orb above to begin hands-free control.",
                        style = MaterialTheme.typography.bodySmall,
                        color = AuraTextMuted
                    )
                }
            }
        } else {
            items(recentCommands.take(6), key = { it.id }) { cmd ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = AuraSurface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(0.8.dp, AuraBorder, RoundedCornerShape(12.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "\"${cmd.commandText}\"",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = AuraTextPrimary
                            )
                            Text(
                                text = cmd.responseSpoken,
                                style = MaterialTheme.typography.bodySmall,
                                color = AuraTextSecondary
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = AuraCyan.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = cmd.interpretedIntent,
                                style = MaterialTheme.typography.labelSmall,
                                color = AuraCyan,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
