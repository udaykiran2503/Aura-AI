package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.voice.VoiceMatchResult
import com.example.core.voice.VoiceProfile
import com.example.ui.AuraViewModel
import com.example.ui.theme.AuraAmber
import com.example.ui.theme.AuraBorder
import com.example.ui.theme.AuraCyan
import com.example.ui.theme.AuraEmerald
import com.example.ui.theme.AuraRed
import com.example.ui.theme.AuraSurface
import com.example.ui.theme.AuraSurfaceElevated
import com.example.ui.theme.AuraTextMuted
import com.example.ui.theme.AuraTextPrimary
import com.example.ui.theme.AuraTextSecondary
import com.example.ui.theme.AuraVioletGlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun VoiceProfileScreen(
    viewModel: AuraViewModel,
    modifier: Modifier = Modifier
) {
    val profile by viewModel.primaryVoiceProfile.collectAsStateWithLifecycle()
    val enrollmentStep by viewModel.enrollmentStep.collectAsStateWithLifecycle()
    val testVerificationResult by viewModel.lastVerificationResult.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Security Banner
        SecurityRequirementBanner()

        // Voice Profile Status Card
        VoiceProfileStatusCard(
            profile = profile,
            onStartEnrollment = { viewModel.startEnrollment() },
            onResetProfile = { viewModel.resetVoiceProfile() }
        )

        // Step-by-Step Enrollment Wizard
        AnimatedVisibility(visible = enrollmentStep > 0) {
            EnrollmentWizardCard(
                currentStep = enrollmentStep,
                onRecordSample = { viewModel.recordEnrollmentSample() },
                onCancel = { viewModel.cancelEnrollment() }
            )
        }

        // Voice Match Verification Simulator
        VoiceVerificationSimulatorCard(
            profile = profile,
            verificationResult = testVerificationResult,
            onTest = { viewModel.testVoiceVerification() }
        )

        // Device Authentication Gate Policy
        DeviceAuthenticationGateCard(
            profile = profile,
            onToggleRequireAuth = { requireAuth ->
                viewModel.setRequireDeviceAuthForSensitive(requireAuth)
            }
        )

        Spacer(modifier = Modifier.height(30.dp))
    }
}

@Composable
private fun SecurityRequirementBanner() {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = AuraSurfaceElevated),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, AuraBorder, RoundedCornerShape(18.dp))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(AuraAmber.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = AuraAmber,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text(
                    text = "Zero-Trust Identity Policy",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = AuraAmber
                )
                Text(
                    text = "Voice recognition personalizes interactions and verifies speakers. However, sensitive operations (calls, messages, security changes) always require device authentication.",
                    style = MaterialTheme.typography.bodySmall,
                    color = AuraTextSecondary
                )
            }
        }
    }
}

@Composable
private fun VoiceProfileStatusCard(
    profile: VoiceProfile?,
    onStartEnrollment: () -> Unit,
    onResetProfile: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = AuraSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, AuraBorder, RoundedCornerShape(20.dp))
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (profile != null) AuraEmerald.copy(alpha = 0.15f)
                                else AuraCyan.copy(alpha = 0.15f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (profile != null) Icons.Default.VerifiedUser else Icons.Default.RecordVoiceOver,
                            contentDescription = null,
                            tint = if (profile != null) AuraEmerald else AuraCyan,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = if (profile != null) profile.userName else "No Profile Registered",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = AuraTextPrimary
                        )
                        Text(
                            text = if (profile != null) "Primary Authorized Voice" else "Open Guest Mode",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (profile != null) AuraEmerald else AuraTextSecondary
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (profile != null) AuraEmerald.copy(alpha = 0.15f) else AuraAmber.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = if (profile != null) "ENROLLED" else "UNENROLLED",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (profile != null) AuraEmerald else AuraAmber,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            if (profile != null) {
                Spacer(modifier = Modifier.height(14.dp))
                val dateStr = SimpleDateFormat("MMM d, yyyy h:mm a", Locale.getDefault()).format(Date(profile.enrolledTimestamp))
                Text(
                    text = "Enrolled: $dateStr",
                    style = MaterialTheme.typography.labelSmall,
                    color = AuraTextMuted
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    AcousticPill(label = "Pitch", value = "${profile.averagePitchHz.toInt()} Hz")
                    AcousticPill(label = "Samples", value = "${profile.sampleCount} Takes")
                    AcousticPill(label = "Threshold", value = "${(profile.confidenceThreshold * 100).toInt()}%")
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedButton(
                        onClick = onStartEnrollment,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Re-enroll Voice", color = AuraCyan)
                    }
                    OutlinedButton(
                        onClick = onResetProfile,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AuraRed)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Reset")
                    }
                }
            } else {
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "Registering your voice allows Aura to distinguish your voice commands from background television, radio, or surrounding voices.",
                    style = MaterialTheme.typography.bodySmall,
                    color = AuraTextSecondary
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = onStartEnrollment,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AuraCyan),
                    modifier = Modifier.fillMaxWidth().testTag("enroll_voice_button")
                ) {
                    Icon(Icons.Default.Mic, contentDescription = null, tint = Color(0xFF00363A))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Register Voice Profile", color = Color(0xFF00363A), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun AcousticPill(label: String, value: String) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = AuraSurfaceElevated,
        modifier = Modifier.border(0.8.dp, AuraBorder, RoundedCornerShape(8.dp))
    ) {
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = AuraTextMuted, fontSize = 10.sp)
            Text(value, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = AuraCyan)
        }
    }
}

@Composable
private fun EnrollmentWizardCard(
    currentStep: Int,
    onRecordSample: () -> Unit,
    onCancel: () -> Unit
) {
    val phrases = listOf(
        "\"Hey Aura, this is my authorized voice.\"",
        "\"Hey Aura, unlock my personal assistant.\"",
        "\"Hey Aura, good morning.\""
    )

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0C243B)),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, AuraCyan, RoundedCornerShape(20.dp))
            .testTag("enrollment_wizard_card")
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Voice Enrollment: Step $currentStep of 3",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = AuraCyan
                )
                Text(
                    text = "${(currentStep / 3f * 100).toInt()}%",
                    color = AuraCyan,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            LinearProgressIndicator(
                progress = { currentStep / 3f },
                color = AuraCyan,
                trackColor = Color(0xFF061522),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
            )

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Please speak the phrase aloud clearly:",
                style = MaterialTheme.typography.bodySmall,
                color = AuraTextSecondary
            )

            Spacer(modifier = Modifier.height(8.dp))

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFF081C30),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AuraBorder, RoundedCornerShape(12.dp))
            ) {
                Text(
                    text = phrases.getOrElse(currentStep - 1) { phrases[0] },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White,
                    modifier = Modifier.padding(16.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = onRecordSample,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AuraCyan),
                    modifier = Modifier.weight(1f).testTag("record_sample_button")
                ) {
                    Icon(Icons.Default.Mic, contentDescription = null, tint = Color(0xFF00363A))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (currentStep == 3) "Complete & Save Profile" else "Record Sample $currentStep",
                        color = Color(0xFF00363A),
                        fontWeight = FontWeight.Bold
                    )
                }

                OutlinedButton(
                    onClick = onCancel,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Cancel", color = AuraTextSecondary)
                }
            }
        }
    }
}

@Composable
private fun VoiceVerificationSimulatorCard(
    profile: VoiceProfile?,
    verificationResult: VoiceMatchResult?,
    onTest: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = AuraSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, AuraBorder, RoundedCornerShape(20.dp))
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text(
                text = "Voice Match Verification Test",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = AuraTextPrimary
            )
            Text(
                text = "Simulate an acoustic match analysis against your stored biometric voice features.",
                style = MaterialTheme.typography.bodySmall,
                color = AuraTextSecondary
            )

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onTest,
                enabled = profile != null,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AuraSurfaceElevated),
                modifier = Modifier.fillMaxWidth().testTag("test_voice_match_button")
            ) {
                Icon(Icons.Default.Fingerprint, contentDescription = null, tint = AuraCyan)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Test Voice Acoustic Verification", color = AuraCyan)
            }

            if (verificationResult != null) {
                Spacer(modifier = Modifier.height(12.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (verificationResult.isMatch) AuraEmerald.copy(alpha = 0.1f) else AuraRed.copy(alpha = 0.1f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            1.dp,
                            if (verificationResult.isMatch) AuraEmerald.copy(alpha = 0.4f) else AuraRed.copy(alpha = 0.4f),
                            RoundedCornerShape(12.dp)
                        )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (verificationResult.isMatch) Icons.Default.CheckCircle else Icons.Default.Warning,
                                contentDescription = null,
                                tint = if (verificationResult.isMatch) AuraEmerald else AuraRed,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = verificationResult.statusDescription,
                                fontWeight = FontWeight.Bold,
                                color = if (verificationResult.isMatch) AuraEmerald else AuraRed
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Acoustic match confidence: ${verificationResult.confidencePercent}%. Device authentication required for sensitive operations: ${verificationResult.requiresDeviceAuth}.",
                            style = MaterialTheme.typography.bodySmall,
                            color = AuraTextSecondary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DeviceAuthenticationGateCard(
    profile: VoiceProfile?,
    onToggleRequireAuth: (Boolean) -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = AuraSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, AuraBorder, RoundedCornerShape(20.dp))
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Require Device Authentication",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = AuraTextPrimary
                    )
                    Text(
                        text = "Mandate Device PIN, Pattern, or Fingerprint confirmation before making phone calls, sending messages, or changing device security settings.",
                        style = MaterialTheme.typography.bodySmall,
                        color = AuraTextSecondary
                    )
                }

                Switch(
                    checked = profile?.requireDeviceAuthForSensitive ?: true,
                    onCheckedChange = onToggleRequireAuth,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = AuraCyan,
                        checkedTrackColor = AuraCyan.copy(alpha = 0.3f)
                    ),
                    modifier = Modifier.testTag("require_device_auth_switch")
                )
            }
        }
    }
}
