package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SdStorage
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.hardware.CapabilityItem
import com.example.core.hardware.DeviceSpecs
import com.example.core.hardware.FeatureStatus
import com.example.core.hardware.OperatingMode
import com.example.ui.AuraViewModel
import com.example.ui.theme.AuraAmber
import com.example.ui.theme.AuraBorder
import com.example.ui.theme.AuraCyan
import com.example.ui.theme.AuraEmerald
import com.example.ui.theme.AuraRed
import com.example.ui.theme.AuraSurface
import com.example.ui.theme.AuraSurfaceElevated
import com.example.ui.theme.AuraTextMuted
import com.example.ui.theme.AuraTextPrimary
import com.example.ui.theme.AuraTextSecondary
import com.example.ui.theme.AuraVioletGlow

@Composable
fun CompatibilityScreen(
    viewModel: AuraViewModel,
    modifier: Modifier = Modifier
) {
    val specs by viewModel.deviceSpecs.collectAsStateWithLifecycle()
    val operatingMode by viewModel.operatingMode.collectAsStateWithLifecycle()
    val capabilities by viewModel.capabilitiesMatrix.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = "Universal Compatibility",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = AuraCyan
                    )
                    Text(
                        text = "Hardware diagnostics & adaptive operating profile",
                        style = MaterialTheme.typography.bodySmall,
                        color = AuraTextSecondary
                    )
                }
                IconButton(onClick = { viewModel.refreshHardwareDiagnostics() }) {
                    Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = AuraCyan)
                }
            }
        }

        // Hardware Specs Grid
        specs?.let { s ->
            item {
                DeviceSpecsCard(s)
            }
        }

        // Operating Mode Selector
        item {
            OperatingModeSelectorCard(
                currentMode = operatingMode,
                onSelectMode = { viewModel.setOperatingMode(it) }
            )
        }

        // Capabilities Matrix
        item {
            Text(
                text = "Hardware Capabilities Matrix",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = AuraTextPrimary,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        items(capabilities, key = { it.featureName }) { cap ->
            CapabilityItemRow(cap)
        }

        item {
            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}

@Composable
private fun DeviceSpecsCard(specs: DeviceSpecs) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = AuraSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, AuraBorder, RoundedCornerShape(20.dp))
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(AuraCyan.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PhoneAndroid,
                        contentDescription = null,
                        tint = AuraCyan,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "${specs.manufacturer} ${specs.model}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = AuraTextPrimary
                    )
                    Text(
                        text = "Android ${specs.androidVersion} (API ${specs.apiLevel}) • ${specs.cpuArch}",
                        style = MaterialTheme.typography.bodySmall,
                        color = AuraTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                MetricCard(
                    icon = Icons.Default.Memory,
                    label = "RAM Available",
                    value = "${specs.availableRamMb} / ${specs.totalRamMb} MB",
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    icon = Icons.Default.SdStorage,
                    label = "Storage",
                    value = "${specs.availableStorageGb} / ${specs.totalStorageGb} GB",
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    icon = Icons.Default.BatteryChargingFull,
                    label = "Battery",
                    value = "${specs.batteryPercent}% ${if (specs.isCharging) "(Chg)" else ""}",
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun MetricCard(icon: ImageVector, label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = AuraSurfaceElevated,
        modifier = modifier.border(0.8.dp, AuraBorder, RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Icon(icon, contentDescription = null, tint = AuraCyan, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, color = AuraTextMuted, fontSize = 9.sp)
            Text(value, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = AuraTextPrimary)
        }
    }
}

@Composable
private fun OperatingModeSelectorCard(
    currentMode: OperatingMode,
    onSelectMode: (OperatingMode) -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = AuraSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, AuraBorder, RoundedCornerShape(20.dp))
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text(
                text = "Adaptive Operating Mode",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = AuraTextPrimary
            )
            Text(
                text = "Automatically selected based on RAM, CPU and API level, or override manually:",
                style = MaterialTheme.typography.bodySmall,
                color = AuraTextSecondary
            )

            Spacer(modifier = Modifier.height(14.dp))

            OperatingMode.values().forEach { mode ->
                val isSelected = currentMode == mode
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = if (isSelected) AuraSurfaceElevated else AuraSurface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .border(
                            1.dp,
                            if (isSelected) AuraCyan else AuraBorder.copy(alpha = 0.5f),
                            RoundedCornerShape(14.dp)
                        )
                        .clickable { onSelectMode(mode) }
                        .testTag("mode_option_${mode.name}")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) AuraCyan else AuraTextMuted)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = mode.title,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) AuraCyan else AuraTextPrimary
                                )
                                if (isSelected) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = AuraCyan.copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = "ACTIVE",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = AuraCyan,
                                            fontSize = 9.sp,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                            Text(
                                text = mode.subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = AuraTextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CapabilityItemRow(item: CapabilityItem) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AuraSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(0.8.dp, AuraBorder, RoundedCornerShape(14.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = item.featureName,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = AuraTextPrimary
                )

                val (badgeBg, badgeTextColor) = when (item.status) {
                    FeatureStatus.SUPPORTED -> Pair(AuraEmerald.copy(alpha = 0.15f), AuraEmerald)
                    FeatureStatus.REQUIRES_PERMISSION -> Pair(AuraCyan.copy(alpha = 0.15f), AuraCyan)
                    FeatureStatus.MANUFACTURER_LIMITED -> Pair(AuraAmber.copy(alpha = 0.15f), AuraAmber)
                    FeatureStatus.NOT_SUPPORTED -> Pair(AuraRed.copy(alpha = 0.15f), AuraRed)
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = badgeBg,
                    modifier = Modifier.padding(start = 8.dp)
                ) {
                    Text(
                        text = item.status.label,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = badgeTextColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = item.details,
                style = MaterialTheme.typography.bodySmall,
                color = AuraTextSecondary
            )
        }
    }
}
