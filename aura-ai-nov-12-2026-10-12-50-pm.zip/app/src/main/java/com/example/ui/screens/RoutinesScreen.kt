package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.model.Routine
import com.example.core.model.RoutineStep
import com.example.core.model.RoutineStepType
import com.example.ui.AuraViewModel
import com.example.ui.theme.AuraAmber
import com.example.ui.theme.AuraBorder
import com.example.ui.theme.AuraCyan
import com.example.ui.theme.AuraEmerald
import com.example.ui.theme.AuraRed
import com.example.ui.theme.AuraSurface
import com.example.ui.theme.AuraSurfaceElevated
import com.example.ui.theme.AuraTextMuted
import com.example.ui.theme.AuraTextPrimary
import com.example.ui.theme.AuraTextSecondary
import com.example.ui.theme.AuraVioletGlow
import java.util.UUID

@Composable
fun RoutinesScreen(
    viewModel: AuraViewModel,
    modifier: Modifier = Modifier
) {
    val routines by viewModel.allRoutines.collectAsStateWithLifecycle()
    val executionState by viewModel.routineExecutionState.collectAsStateWithLifecycle()

    var showCreateDialog by remember { mutableStateOf(false) }
    var routineToDelete by remember { mutableStateOf<Routine?>(null) }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                // Header Banner
                RoutineHeaderBanner(
                    activeCount = routines.count { it.isEnabled },
                    totalCount = routines.size
                )
            }

            // Real-time Routine Execution Banner
            if (executionState.isRunning || executionState.currentStepLabel == "Completed") {
                item {
                    RoutineExecutionCard(executionState = executionState)
                }
            }

            item {
                Text(
                    text = "Configured Voice Routines",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = AuraTextPrimary,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            items(routines, key = { it.id }) { routine ->
                RoutineCard(
                    routine = routine,
                    isExecuting = executionState.isRunning && executionState.routineId == routine.id,
                    onRun = { viewModel.runRoutine(routine) },
                    onTogglePause = { viewModel.toggleRoutinePause(routine.id, routine.isEnabled) },
                    onDelete = { routineToDelete = routine }
                )
            }

            item {
                Spacer(modifier = Modifier.height(80.dp)) // padding for FAB
            }
        }

        // Floating Action Button to create custom routine
        FloatingActionButton(
            onClick = { showCreateDialog = true },
            containerColor = AuraCyan,
            contentColor = Color(0xFF00363A),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(24.dp)
                .testTag("create_routine_fab")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 16.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Create Routine")
                Spacer(modifier = Modifier.width(6.dp))
                Text("New Routine", fontWeight = FontWeight.Bold)
            }
        }
    }

    // Create Routine Dialog
    if (showCreateDialog) {
        CreateRoutineDialog(
            onDismiss = { showCreateDialog = false },
            onCreate = { name, trigger, desc, icon, steps ->
                viewModel.createCustomRoutine(name, trigger, desc, icon, steps)
                showCreateDialog = false
            }
        )
    }

    // Delete Confirmation Dialog
    routineToDelete?.let { routine ->
        AlertDialog(
            onDismissRequest = { routineToDelete = null },
            title = { Text("Delete Routine?", color = AuraTextPrimary) },
            text = { Text("Are you sure you want to remove '${routine.name}'? This action cannot be undone.", color = AuraTextSecondary) },
            containerColor = AuraSurfaceElevated,
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteRoutine(routine.id)
                        routineToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AuraRed)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { routineToDelete = null }) {
                    Text("Cancel", color = AuraTextSecondary)
                }
            }
        )
    }
}

@Composable
private fun RoutineHeaderBanner(activeCount: Int, totalCount: Int) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = AuraSurfaceElevated),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, AuraBorder, RoundedCornerShape(20.dp))
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = "Smart Routine Automation",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = AuraCyan
                    )
                    Text(
                        text = "Execute multiple actions with a single voice command",
                        style = MaterialTheme.typography.bodySmall,
                        color = AuraTextSecondary
                    )
                }
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = AuraEmerald.copy(alpha = 0.15f),
                    modifier = Modifier.border(1.dp, AuraEmerald.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                ) {
                    Text(
                        text = "$activeCount / $totalCount Active",
                        color = AuraEmerald,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun RoutineExecutionCard(executionState: com.example.core.routine.RoutineExecutionState) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF003B42)),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, AuraCyan, RoundedCornerShape(18.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (executionState.isRunning) AuraEmerald else AuraCyan)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (executionState.isRunning) "Running: ${executionState.routineName}" else "Finished: ${executionState.routineName}",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
                Text(
                    text = "${executionState.currentStepIndex}/${executionState.totalSteps}",
                    fontWeight = FontWeight.Bold,
                    color = AuraCyan,
                    style = MaterialTheme.typography.labelLarge
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            val progress = if (executionState.totalSteps > 0) {
                executionState.currentStepIndex.toFloat() / executionState.totalSteps.toFloat()
            } else 0f

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = AuraCyan,
                trackColor = Color(0xFF002226)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Current: ${executionState.currentStepLabel}",
                style = MaterialTheme.typography.bodyMedium,
                color = AuraTextPrimary,
                fontWeight = FontWeight.Medium
            )

            if (executionState.executionLog.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Column(
                    verticalArrangement = Arrangement.spacedBy(3.dp),
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    executionState.executionLog.takeLast(3).forEach { logLine ->
                        Text(
                            text = logLine,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFC7F9FF)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RoutineCard(
    routine: Routine,
    isExecuting: Boolean,
    onRun: () -> Unit,
    onTogglePause: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = AuraSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (isExecuting) AuraCyan else if (routine.isEnabled) AuraBorder else AuraBorder.copy(alpha = 0.4f),
                RoundedCornerShape(18.dp)
            )
            .testTag("routine_card_${routine.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Title Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (routine.isEnabled) AuraCyan.copy(alpha = 0.15f)
                                else AuraTextMuted.copy(alpha = 0.15f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = getIconForName(routine.iconName),
                            contentDescription = routine.name,
                            tint = if (routine.isEnabled) AuraCyan else AuraTextMuted,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = routine.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (routine.isEnabled) AuraTextPrimary else AuraTextMuted
                            )
                            if (!routine.isCustom) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = AuraVioletGlow.copy(alpha = 0.2f),
                                    modifier = Modifier.padding(horizontal = 4.dp)
                                ) {
                                    Text(
                                        text = "PRESET",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = AuraVioletGlow,
                                        fontSize = 9.sp,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = routine.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = AuraTextSecondary,
                            maxLines = 2
                        )
                    }
                }

                // Pause / Resume Toggle Switch
                Switch(
                    checked = routine.isEnabled,
                    onCheckedChange = { onTogglePause() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = AuraCyan,
                        checkedTrackColor = AuraCyan.copy(alpha = 0.3f),
                        uncheckedThumbColor = AuraTextMuted,
                        uncheckedTrackColor = AuraSurfaceElevated
                    ),
                    modifier = Modifier.testTag("routine_toggle_${routine.id}")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Trigger phrase pill
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = AuraSurfaceElevated,
                modifier = Modifier.border(1.dp, AuraBorder, RoundedCornerShape(8.dp))
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Voice Trigger",
                        tint = AuraCyan,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Say: \"Hey Aura, ${routine.triggerPhrase}\"",
                        style = MaterialTheme.typography.labelSmall,
                        color = AuraCyan,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Sequential Steps List
            Text(
                text = "Sequential Steps (${routine.steps.size}):",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = AuraTextSecondary
            )

            Spacer(modifier = Modifier.height(6.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                routine.steps.forEachIndexed { idx, step ->
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = AuraSurfaceElevated,
                        modifier = Modifier.border(0.8.dp, AuraBorder, RoundedCornerShape(6.dp))
                    ) {
                        Text(
                            text = "${idx + 1}. ${step.label}",
                            style = MaterialTheme.typography.labelSmall,
                            color = AuraTextPrimary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action Buttons Row: Run Now / Delete
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = onRun,
                    enabled = routine.isEnabled && !isExecuting,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AuraCyan),
                    modifier = Modifier.testTag("run_routine_${routine.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Run",
                        tint = Color(0xFF00363A),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isExecuting) "Running..." else "Run Routine",
                        color = Color(0xFF00363A),
                        fontWeight = FontWeight.Bold
                    )
                }

                if (routine.isCustom) {
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.testTag("delete_routine_${routine.id}")
                    ) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "Delete Routine",
                            tint = AuraRed
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CreateRoutineDialog(
    onDismiss: () -> Unit,
    onCreate: (name: String, trigger: String, desc: String, icon: String, steps: List<RoutineStep>) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var trigger by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    val steps = remember { mutableStateListOf<RoutineStep>() }

    var selectedStepType by remember { mutableStateOf(RoutineStepType.ANNOUNCE_TIME) }
    var stepParameter by remember { mutableStateOf("") }
    var stepExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Voice Routine", color = AuraTextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Routine Name (e.g., Focus Mode)") },
                    singleLine = true,
                    colors = outlinedColors(),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = trigger,
                    onValueChange = { trigger = it },
                    label = { Text("Voice Trigger Phrase (e.g., focus mode)") },
                    placeholder = { Text("What you say after 'Hey Aura'") },
                    singleLine = true,
                    colors = outlinedColors(),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description") },
                    colors = outlinedColors(),
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "Add Sequential Steps:",
                    fontWeight = FontWeight.SemiBold,
                    color = AuraCyan,
                    style = MaterialTheme.typography.labelLarge
                )

                // Step Type Dropdown
                ExposedDropdownMenuBox(
                    expanded = stepExpanded,
                    onExpandedChange = { stepExpanded = !stepExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedStepType.displayName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Step Action") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = stepExpanded) },
                        colors = outlinedColors(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = stepExpanded,
                        onDismissRequest = { stepExpanded = false }
                    ) {
                        RoutineStepType.values().forEach { type ->
                            DropdownMenuItem(
                                text = { Text(type.displayName) },
                                onClick = {
                                    selectedStepType = type
                                    stepExpanded = false
                                }
                            )
                        }
                    }
                }

                // Step parameter if applicable
                when (selectedStepType) {
                    RoutineStepType.SET_VOLUME -> {
                        OutlinedTextField(
                            value = stepParameter,
                            onValueChange = { stepParameter = it },
                            label = { Text("Volume percentage (0-100)") },
                            placeholder = { Text("70") },
                            colors = outlinedColors(),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    RoutineStepType.SPEAK_TEXT -> {
                        OutlinedTextField(
                            value = stepParameter,
                            onValueChange = { stepParameter = it },
                            label = { Text("Spoken message text") },
                            colors = outlinedColors(),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    RoutineStepType.LAUNCH_APP -> {
                        OutlinedTextField(
                            value = stepParameter,
                            onValueChange = { stepParameter = it },
                            label = { Text("App Name or Package (e.g., maps, whatsapp)") },
                            colors = outlinedColors(),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    else -> {}
                }

                Button(
                    onClick = {
                        val newStep = RoutineStep(
                            id = "step_" + UUID.randomUUID().toString().take(6),
                            type = selectedStepType,
                            label = selectedStepType.displayName,
                            parameter = stepParameter
                        )
                        steps.add(newStep)
                        stepParameter = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AuraSurfaceElevated),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = AuraCyan)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Add Step to Routine", color = AuraCyan)
                }

                // Display added steps
                if (steps.isNotEmpty()) {
                    Text("Configured Steps (${steps.size}):", color = AuraTextSecondary)
                    steps.forEachIndexed { i, s ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(AuraSurface, RoundedCornerShape(8.dp))
                                .padding(8.dp)
                        ) {
                            Text("${i + 1}. ${s.label}", color = AuraTextPrimary)
                            IconButton(onClick = { steps.removeAt(i) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Remove", tint = AuraRed)
                            }
                        }
                    }
                }
            }
        },
        containerColor = AuraSurfaceElevated,
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank() && trigger.isNotBlank()) {
                        onCreate(name, trigger, description, "flash_on", steps.toList())
                    }
                },
                enabled = name.isNotBlank() && trigger.isNotBlank() && steps.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(containerColor = AuraCyan)
            ) {
                Text("Save Routine", color = Color(0xFF00363A), fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = AuraTextSecondary)
            }
        }
    )
}

@Composable
private fun outlinedColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = AuraCyan,
    unfocusedBorderColor = AuraBorder,
    focusedTextColor = AuraTextPrimary,
    unfocusedTextColor = AuraTextPrimary,
    focusedLabelColor = AuraCyan,
    unfocusedLabelColor = AuraTextSecondary
)

private fun getIconForName(name: String): ImageVector {
    return when (name.lowercase()) {
        "wb_sunny" -> Icons.Default.WbSunny
        "bedtime" -> Icons.Default.Bedtime
        "directions_car" -> Icons.Default.DirectionsCar
        "fitness_center" -> Icons.Default.FitnessCenter
        "emergency" -> Icons.Default.Emergency
        else -> Icons.Default.WbSunny
    }
}
