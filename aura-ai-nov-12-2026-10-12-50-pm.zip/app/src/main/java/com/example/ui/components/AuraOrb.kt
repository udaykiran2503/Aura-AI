package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.core.voice.AssistantVoiceState
import com.example.ui.theme.AuraCyan
import com.example.ui.theme.AuraEmerald
import com.example.ui.theme.AuraMagenta
import com.example.ui.theme.AuraRed
import com.example.ui.theme.AuraViolet
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun AuraOrb(
    voiceState: AssistantVoiceState,
    audioRms: Float,
    modifier: Modifier = Modifier,
    size: Dp = 200.dp,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_animation")

    // Breathing pulse
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    // Continuous rotation angle
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    // Dynamic color selection based on state
    val (primaryGlow, secondaryGlow) = when (voiceState) {
        AssistantVoiceState.IDLE -> Pair(AuraCyan, AuraViolet)
        AssistantVoiceState.LISTENING -> Pair(AuraCyan, Color(0xFF64FFDA))
        AssistantVoiceState.PROCESSING -> Pair(AuraViolet, AuraMagenta)
        AssistantVoiceState.SPEAKING -> Pair(AuraEmerald, AuraCyan)
        AssistantVoiceState.ERROR -> Pair(AuraRed, AuraMagenta)
    }

    val dynamicAudioBoost = if (voiceState == AssistantVoiceState.LISTENING) (audioRms * 0.4f) else 0f
    val effectiveScale = (pulseScale + dynamicAudioBoost).coerceIn(0.85f, 1.45f)

    Box(
        modifier = modifier
            .size(size)
            .testTag("aura_assistant_orb")
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = false, radius = size / 2),
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val baseRadius = (this.size.minDimension / 2.8f) * effectiveScale

            // 1. Outer ambient glow ring
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryGlow.copy(alpha = 0.35f),
                        secondaryGlow.copy(alpha = 0.15f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = baseRadius * 1.55f
                ),
                radius = baseRadius * 1.55f,
                center = center
            )

            // 2. Animated acoustic wave rings
            val waveRings = 3
            for (i in 1..waveRings) {
                val ringRadius = baseRadius * (1f + (i * 0.15f) + dynamicAudioBoost * 0.2f)
                val alpha = (0.4f / i) + (dynamicAudioBoost * 0.3f)
                drawCircle(
                    color = primaryGlow.copy(alpha = alpha.coerceIn(0.05f, 0.7f)),
                    radius = ringRadius,
                    center = center,
                    style = Stroke(width = (2.5f - i * 0.5f).coerceAtLeast(1f).dp.toPx())
                )
            }

            // 3. Inner Orb gradient core
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.95f),
                        primaryGlow.copy(alpha = 0.9f),
                        secondaryGlow.copy(alpha = 0.85f),
                        Color(0xFF090D1A)
                    ),
                    center = Offset(center.x - baseRadius * 0.2f, center.y - baseRadius * 0.2f),
                    radius = baseRadius
                ),
                radius = baseRadius,
                center = center
            )

            // 4. Rotating energy nodes
            val nodeCount = 6
            for (j in 0 until nodeCount) {
                val angleRad = Math.toRadians((rotationAngle + j * (360f / nodeCount)).toDouble())
                val orbitRadius = baseRadius * 0.72f
                val nodeX = center.x + (orbitRadius * cos(angleRad)).toFloat()
                val nodeY = center.y + (orbitRadius * sin(angleRad)).toFloat()

                drawCircle(
                    color = Color.White.copy(alpha = 0.75f),
                    radius = 3.dp.toPx(),
                    center = Offset(nodeX, nodeY)
                )
            }
        }
    }
}
