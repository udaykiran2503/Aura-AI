package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Aura AI Futuristic Palette
val AuraDeepBg = Color(0xFF090D1A)
val AuraSurface = Color(0xFF11172A)
val AuraSurfaceElevated = Color(0xFF19223D)
val AuraSurfaceVariant = Color(0xFF222D4F)
val AuraBorder = Color(0xFF2A365C)

// Neon & Energy Accents
val AuraCyan = Color(0xFF00F0FF)
val AuraCyanDim = Color(0xFF00A3AD)
val AuraViolet = Color(0xFF9D4EDD)
val AuraVioletGlow = Color(0xFFC77DFF)
val AuraMagenta = Color(0xFFFF007F)
val AuraEmerald = Color(0xFF00E676)
val AuraAmber = Color(0xFFFFB703)
val AuraRed = Color(0xFFFF3366)

// Text & Neutral tokens
val AuraTextPrimary = Color(0xFFF1F5F9)
val AuraTextSecondary = Color(0xFF94A3B8)
val AuraTextMuted = Color(0xFF64748B)

// Light Theme equivalents
val AuraLightBg = Color(0xFFF4F7FB)
val AuraLightSurface = Color(0xFFFFFFFF)
val AuraLightSurfaceElevated = Color(0xFFEBF1F9)
val AuraLightPrimary = Color(0xFF007A87)
val AuraLightSecondary = Color(0xFF7B2CBF)
