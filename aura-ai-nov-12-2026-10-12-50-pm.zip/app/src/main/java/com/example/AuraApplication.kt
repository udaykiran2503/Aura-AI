package com.example

import android.app.Application
import com.example.core.device.DeviceController
import com.example.core.engine.ActionPlanner
import com.example.core.engine.IntentParser
import com.example.core.engine.SafetyController
import com.example.core.hardware.DeviceCompatibilityManager
import com.example.core.routine.RoutineExecutor
import com.example.core.voice.VoiceManager
import com.example.core.voice.VoiceProfileManager
import com.example.data.local.AuraDatabase
import com.example.data.repository.RoutineRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AuraApplication : Application() {

    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    val database by lazy { AuraDatabase.getInstance(this) }
    val routineRepository by lazy { RoutineRepository(database.routineDao()) }
    val deviceCompatibilityManager by lazy { DeviceCompatibilityManager(this) }
    val deviceController by lazy { DeviceController(this) }
    val safetyController by lazy { SafetyController(database.securityLogDao()) }
    val voiceProfileManager by lazy { VoiceProfileManager(database.voiceProfileDao(), database.securityLogDao(), this) }

    lateinit var voiceManager: VoiceManager
    lateinit var intentParser: IntentParser
    lateinit var routineExecutor: RoutineExecutor
    lateinit var actionPlanner: ActionPlanner

    override fun onCreate() {
        super.onCreate()

        intentParser = IntentParser(routineRepository)

        voiceManager = VoiceManager(
            context = this,
            onVoiceResult = { heardText ->
                applicationScope.launch {
                    val parsed = intentParser.parse(heardText)
                    actionPlanner.planAndExecute(parsed)
                }
            }
        )

        routineExecutor = RoutineExecutor(
            context = this,
            deviceController = deviceController,
            voiceManager = voiceManager,
            routineRepository = routineRepository
        )

        actionPlanner = ActionPlanner(
            context = this,
            deviceController = deviceController,
            voiceManager = voiceManager,
            routineRepository = routineRepository,
            routineExecutor = routineExecutor,
            voiceProfileManager = voiceProfileManager,
            safetyController = safetyController,
            voiceCommandDao = database.voiceCommandDao()
        )

        // Seed default routines and permissions asynchronously
        applicationScope.launch(Dispatchers.IO) {
            routineRepository.ensureDefaultRoutines()
        }
    }
}
