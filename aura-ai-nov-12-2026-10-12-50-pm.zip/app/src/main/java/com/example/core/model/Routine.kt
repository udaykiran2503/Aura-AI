package com.example.core.model

enum class RoutineStepType(val displayName: String, val description: String) {
    ANNOUNCE_TIME("Announce Time & Date", "Speaks the current time and date aloud"),
    ANNOUNCE_WEATHER("Check Weather", "Announces local weather forecast"),
    ANNOUNCE_SCHEDULE("Today's Schedule", "Summarizes today's reminders and calendar schedule"),
    SET_VOLUME("Set Phone Volume", "Adjusts media/ring volume level (0-100%)"),
    SET_BRIGHTNESS("Set Screen Brightness", "Adjusts display brightness (0-100%)"),
    TOGGLE_FLASHLIGHT("Control Flashlight", "Turns phone flashlight ON or OFF"),
    LAUNCH_APP("Launch Application", "Opens specified application by name or package"),
    SPEAK_TEXT("Voice Announcement", "Speaks a custom personalized message"),
    SET_ALARM("Set Alarm", "Configures alarm at designated time"),
    CHECK_BATTERY("Battery Summary", "Announces remaining battery charge and status"),
    FIND_PHONE_ALERT("Audible Siren Alert", "Sounds a loud alert tone to locate phone"),
    OPEN_SETTINGS("Open Device Settings", "Navigates to specific Android settings page")
}

data class RoutineStep(
    val id: String,
    val type: RoutineStepType,
    val label: String,
    val parameter: String = "" // e.g. "70" for volume, "com.whatsapp" for app, "Hyderabad" for weather
)

data class Routine(
    val id: String,
    val name: String,
    val triggerPhrase: String,
    val description: String,
    val iconName: String,
    val isEnabled: Boolean = true,
    val isCustom: Boolean = false,
    val steps: List<RoutineStep> = emptyList(),
    val createdAt: Long = System.currentTimeMillis(),
    val lastExecutedAt: Long? = null
)
