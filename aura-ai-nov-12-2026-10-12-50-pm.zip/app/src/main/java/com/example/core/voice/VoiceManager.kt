package com.example.core.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class AssistantVoiceState {
    IDLE,
    LISTENING,
    PROCESSING,
    SPEAKING,
    ERROR
}

class VoiceManager(
    private val context: Context,
    private val onVoiceResult: (String) -> Unit,
    private val onError: (String) -> Unit = {}
) : RecognitionListener, TextToSpeech.OnInitListener {

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsInitialized = false

    private val _voiceState = MutableStateFlow(AssistantVoiceState.IDLE)
    val voiceState: StateFlow<AssistantVoiceState> = _voiceState.asStateFlow()

    private val _audioRms = MutableStateFlow(0f)
    val audioRms: StateFlow<Float> = _audioRms.asStateFlow()

    private val _currentLanguage = MutableStateFlow("en")
    val currentLanguage: StateFlow<String> = _currentLanguage.asStateFlow()

    init {
        initSpeechRecognizer()
        initTextToSpeech()
    }

    private fun initSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(this@VoiceManager)
            }
        }
    }

    private fun initTextToSpeech() {
        textToSpeech = TextToSpeech(context, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsInitialized = true
            setLanguage(_currentLanguage.value)
            textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _voiceState.value = AssistantVoiceState.SPEAKING
                }

                override fun onDone(utteranceId: String?) {
                    _voiceState.value = AssistantVoiceState.IDLE
                }

                override fun onError(utteranceId: String?) {
                    _voiceState.value = AssistantVoiceState.IDLE
                }
            })
        } else {
            Log.e("VoiceManager", "TTS initialization failed")
        }
    }

    fun setLanguage(langCode: String) {
        _currentLanguage.value = langCode
        if (!isTtsInitialized) return

        val locale = when (langCode.lowercase()) {
            "te" -> Locale("te", "IN") // Telugu
            "hi" -> Locale("hi", "IN") // Hindi
            "ta" -> Locale("ta", "IN") // Tamil
            "kn" -> Locale("kn", "IN") // Kannada
            else -> Locale.ENGLISH
        }

        val result = textToSpeech?.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            // fallback to English
            textToSpeech?.language = Locale.ENGLISH
        }
    }

    fun startListening() {
        if (speechRecognizer == null) {
            initSpeechRecognizer()
        }
        if (speechRecognizer == null) {
            onError("Speech recognition not supported on this device.")
            return
        }

        stopSpeaking()

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            val langTag = when (_currentLanguage.value) {
                "te" -> "te-IN"
                "hi" -> "hi-IN"
                "ta" -> "ta-IN"
                "kn" -> "kn-IN"
                else -> "en-US"
            }
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }

        try {
            speechRecognizer?.startListening(intent)
            _voiceState.value = AssistantVoiceState.LISTENING
        } catch (e: Exception) {
            _voiceState.value = AssistantVoiceState.ERROR
            onError("Could not start microphone: ${e.message}")
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
            if (_voiceState.value == AssistantVoiceState.LISTENING) {
                _voiceState.value = AssistantVoiceState.IDLE
            }
        } catch (e: Exception) {
            Log.e("VoiceManager", "Stop listening error", e)
        }
    }

    fun speak(text: String, onComplete: (() -> Unit)? = null) {
        if (!isTtsInitialized || text.isBlank()) {
            onComplete?.invoke()
            return
        }

        val utteranceId = "utterance_" + System.currentTimeMillis()
        _voiceState.value = AssistantVoiceState.SPEAKING
        textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stopSpeaking() {
        if (isTtsInitialized) {
            textToSpeech?.stop()
        }
        if (_voiceState.value == AssistantVoiceState.SPEAKING) {
            _voiceState.value = AssistantVoiceState.IDLE
        }
    }

    fun emergencyStop() {
        stopListening()
        stopSpeaking()
        _audioRms.value = 0f
        _voiceState.value = AssistantVoiceState.IDLE
    }

    fun setProcessingState() {
        _voiceState.value = AssistantVoiceState.PROCESSING
    }

    fun destroy() {
        try {
            speechRecognizer?.destroy()
            textToSpeech?.stop()
            textToSpeech?.shutdown()
        } catch (e: Exception) {
            Log.e("VoiceManager", "Destroy error", e)
        }
    }

    // RecognitionListener overrides
    override fun onReadyForSpeech(params: Bundle?) {
        _voiceState.value = AssistantVoiceState.LISTENING
    }

    override fun onBeginningOfSpeech() {}

    override fun onRmsChanged(rmsdB: Float) {
        // Map dB (-2 to 10 typical) to normalized 0f..1f for visualizer
        val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
        _audioRms.value = normalized
    }

    override fun onBufferReceived(buffer: ByteArray?) {}

    override fun onEndOfSpeech() {
        _audioRms.value = 0f
        _voiceState.value = AssistantVoiceState.PROCESSING
    }

    override fun onError(error: Int) {
        _audioRms.value = 0f
        val msg = when (error) {
            SpeechRecognizer.ERROR_NO_MATCH -> "No speech recognized. Please try again."
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Listening timed out."
            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error."
            SpeechRecognizer.ERROR_CLIENT -> "Speech recognition cancelled."
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required."
            SpeechRecognizer.ERROR_NETWORK -> "Network issue occurred during speech recognition."
            else -> "Speech recognizer code: $error"
        }
        _voiceState.value = AssistantVoiceState.IDLE
        Log.w("VoiceManager", "Speech error: $msg")
    }

    override fun onResults(results: Bundle?) {
        _audioRms.value = 0f
        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val heardText = matches?.firstOrNull() ?: ""
        if (heardText.isNotBlank()) {
            _voiceState.value = AssistantVoiceState.PROCESSING
            onVoiceResult(heardText)
        } else {
            _voiceState.value = AssistantVoiceState.IDLE
        }
    }

    override fun onPartialResults(partialResults: Bundle?) {}

    override fun onEvent(eventType: Int, params: Bundle?) {}
}
