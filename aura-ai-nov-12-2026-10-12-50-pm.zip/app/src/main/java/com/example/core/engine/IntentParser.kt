package com.example.core.engine

import com.example.data.repository.RoutineRepository
import java.util.regex.Pattern

data class ParsedIntent(
    val rawText: String,
    val intentName: String,
    val action: AuraAction,
    val confidence: Float = 0.95f,
    val isSensitive: Boolean = false,
    val explanation: String = ""
)

class IntentParser(private val routineRepository: RoutineRepository) {

    suspend fun parse(input: String): ParsedIntent {
        val text = input.trim().lowercase()

        // 1. Emergency stop commands (Immediate)
        if (text == "stop" || text == "cancel" || text == "quiet" || text == "shut up" ||
            text.contains("ఆగు") || text.contains("రుకో") || text == "ruko" || text == "aagu"
        ) {
            return ParsedIntent(
                rawText = input,
                intentName = "EMERGENCY_STOP",
                action = AuraAction.EmergencyStop,
                explanation = "Emergency stop requested."
            )
        }

        // 2. Smart Routine Matching (Check registered routines including "Good Morning")
        val matchedRoutine = routineRepository.findRoutineByTrigger(text)
        if (matchedRoutine != null && matchedRoutine.isEnabled) {
            return ParsedIntent(
                rawText = input,
                intentName = "EXECUTE_ROUTINE",
                action = AuraAction.ExecuteRoutine(matchedRoutine.id, matchedRoutine.name),
                explanation = "Matched active routine: ${matchedRoutine.name}"
            )
        }

        // Check language-specific routine keywords
        if (text.contains("good morning") || text.contains("shubh prabhat") || text.contains("శుభోదయం") || text.contains("subhodayam")) {
            return ParsedIntent(
                rawText = input,
                intentName = "EXECUTE_ROUTINE",
                action = AuraAction.ExecuteRoutine("good_morning", "Good Morning"),
                explanation = "Matched Good Morning routine"
            )
        }
        if (text.contains("bedtime") || text.contains("good night") || text.contains("శుభరాత్రి") || text.contains("shubh ratri")) {
            return ParsedIntent(
                rawText = input,
                intentName = "EXECUTE_ROUTINE",
                action = AuraAction.ExecuteRoutine("bedtime", "Bedtime Routine"),
                explanation = "Matched Bedtime routine"
            )
        }
        if (text.contains("driving mode") || text.contains("start driving") || text.contains("డ్రైవింగ్ మోడ్")) {
            return ParsedIntent(
                rawText = input,
                intentName = "EXECUTE_ROUTINE",
                action = AuraAction.ExecuteRoutine("driving_mode", "Driving Mode"),
                explanation = "Matched Driving Mode routine"
            )
        }

        // 3. Flashlight / Torch
        if (text.contains("flashlight on") || text.contains("torch on") || text.contains("turn on torch") ||
            text.contains("turn on flashlight") || text.contains("switch on flashlight") ||
            text.contains("టార్చ్ ఆన్") || text.contains("torch jalao") || text.contains("लाइट जलाओ") ||
            (text.contains("flashlight") && (text.contains("on") || text.contains("enable") || text.contains("start")))
        ) {
            return ParsedIntent(
                rawText = input,
                intentName = "TOGGLE_FLASHLIGHT",
                action = AuraAction.ToggleFlashlight(true),
                explanation = "Turn on flashlight"
            )
        }
        if (text.contains("flashlight off") || text.contains("torch off") || text.contains("turn off torch") ||
            text.contains("turn off flashlight") || text.contains("switch off flashlight") ||
            text.contains("టార్చ్ ఆఫ్") || text.contains("torch band") || text.contains("लाइट बंद") ||
            (text.contains("flashlight") && (text.contains("off") || text.contains("disable") || text.contains("stop")))
        ) {
            return ParsedIntent(
                rawText = input,
                intentName = "TOGGLE_FLASHLIGHT",
                action = AuraAction.ToggleFlashlight(false),
                explanation = "Turn off flashlight"
            )
        }

        // 4. Find My Phone
        if (text.contains("find my phone") || text.contains("where is my phone") ||
            text.contains("ఫోన్ వెతుకు") || text.contains("फोन ढूंढो") || text.contains("phone dhundo")
        ) {
            return ParsedIntent(
                rawText = input,
                intentName = "FIND_MY_PHONE",
                action = AuraAction.FindMyPhone,
                explanation = "Locate phone with audible alert"
            )
        }

        // 5. Battery Status
        if (text.contains("battery") || text.contains("charge") || text.contains("బ్యాటరీ") || text.contains("बैटरी")) {
            return ParsedIntent(
                rawText = input,
                intentName = "CHECK_BATTERY",
                action = AuraAction.CheckBattery,
                explanation = "Check battery status"
            )
        }

        // 6. Time and Date
        if (text.contains("time") || text.contains("date") || text.contains("సమయం") || text.contains("समय")) {
            return ParsedIntent(
                rawText = input,
                intentName = "CHECK_TIME",
                action = AuraAction.CheckTimeAndDate,
                explanation = "Check time and date"
            )
        }

        // 7. Weather
        if (text.contains("weather") || text.contains("forecast") || text.contains("వాతావరణం") || text.contains("मौसम")) {
            val location = if (text.contains("in ")) text.substringAfter("in ").trim() else "Local Area"
            return ParsedIntent(
                rawText = input,
                intentName = "CHECK_WEATHER",
                action = AuraAction.CheckWeather(location),
                explanation = "Check weather forecast for $location"
            )
        }

        // 8. Volume Control
        if (text.contains("volume") || text.contains("sound") || text.contains("వాల్యూమ్") || text.contains("आवाज")) {
            val percent = extractNumber(text) ?: if (text.contains("up") || text.contains("పెంచు") || text.contains("बढ़ाओ")) 85
            else if (text.contains("down") || text.contains("తగ్గించు") || text.contains("कम")) 30
            else if (text.contains("mute") || text.contains("silent")) 0 else 60
            return ParsedIntent(
                rawText = input,
                intentName = "ADJUST_VOLUME",
                action = AuraAction.AdjustVolume(percent),
                explanation = "Set volume to $percent%"
            )
        }

        // 9. Alarms
        if (text.contains("alarm") || text.contains("wake me up") || text.contains("అలారం") || text.contains("अलार्म")) {
            val hour = extractHour(text) ?: 7
            val minute = extractMinute(text) ?: 0
            return ParsedIntent(
                rawText = input,
                intentName = "SET_ALARM",
                action = AuraAction.SetAlarm(hour, minute, "Aura Wakeup Alarm"),
                explanation = "Set alarm for %02d:%02d".format(hour, minute)
            )
        }

        // 10. Open Application
        if (text.startsWith("open ") || text.startsWith("launch ") || text.startsWith("start ") ||
            text.contains("ఓపెన్") || text.contains("खोलो") || text.contains("kholo")
        ) {
            val appQuery = text
                .replace("open ", "")
                .replace("launch ", "")
                .replace("start ", "")
                .replace("ఓపెన్ చేయి", "")
                .replace("खोलो", "")
                .trim()
            return ParsedIntent(
                rawText = input,
                intentName = "OPEN_APP",
                action = AuraAction.OpenApp(appQuery),
                explanation = "Open app '$appQuery'"
            )
        }

        // 11. Phone Calls
        if (text.startsWith("call ") || text.startsWith("dial ") || text.contains("కాల్ చేయి") || text.contains("कॉल करो")) {
            val target = text.replace("call ", "").replace("dial ", "").replace("కాల్ చేయి", "").trim()
            return ParsedIntent(
                rawText = input,
                intentName = "CALL_PHONE",
                action = AuraAction.OpenPhoneDialer(target),
                isSensitive = true,
                explanation = "Initiate call to $target"
            )
        }

        // 12. Settings
        if (text.contains("settings") || text.contains("wifi") || text.contains("bluetooth") || text.contains("సెట్టింగ్స్")) {
            val type = when {
                text.contains("wifi") -> "wifi"
                text.contains("bluetooth") -> "bluetooth"
                text.contains("sound") -> "sound"
                text.contains("display") -> "display"
                text.contains("battery") -> "battery"
                text.contains("accessibility") -> "accessibility"
                else -> "general"
            }
            return ParsedIntent(
                rawText = input,
                intentName = "OPEN_SETTINGS",
                action = AuraAction.OpenSettings(type),
                explanation = "Open $type settings"
            )
        }

        // 13. Web Search
        if (text.startsWith("search ") || text.startsWith("google ") || text.startsWith("who is ") || text.startsWith("what is ")) {
            val query = text.removePrefix("search ").removePrefix("google ").trim()
            return ParsedIntent(
                rawText = input,
                intentName = "SEARCH_WEB",
                action = AuraAction.SearchWeb(query),
                explanation = "Search web for $query"
            )
        }

        // Fallback General Assistant Response
        return ParsedIntent(
            rawText = input,
            intentName = "GENERAL_CONVERSATION",
            action = AuraAction.GeneralSpeechResponse(
                "I heard '$input'. I can control flashlight, volume, launch apps, announce the time, run your routines, or locate your phone."
            ),
            explanation = "Conversation response"
        )
    }

    private fun extractNumber(text: String): Int? {
        val matcher = Pattern.compile("(\\d+)").matcher(text)
        return if (matcher.find()) matcher.group(1)?.toIntOrNull() else null
    }

    private fun extractHour(text: String): Int? {
        val matcher = Pattern.compile("(\\d{1,2})\\s*(am|pm)?").matcher(text)
        if (matcher.find()) {
            var h = matcher.group(1)?.toIntOrNull() ?: return null
            val ampm = matcher.group(2)
            if (ampm != null && ampm.equals("pm", ignoreCase = true) && h < 12) {
                h += 12
            }
            return h
        }
        return null
    }

    private fun extractMinute(text: String): Int? {
        val matcher = Pattern.compile(":\\s*(\\d{2})").matcher(text)
        return if (matcher.find()) matcher.group(1)?.toIntOrNull() else 0
    }
}
