package com.example.core.engine

sealed class AuraAction {
    data class ExecuteRoutine(val routineId: String, val routineName: String) : AuraAction()
    data class OpenApp(val appQuery: String) : AuraAction()
    data class ToggleFlashlight(val enable: Boolean) : AuraAction()
    data class AdjustVolume(val percent: Int) : AuraAction()
    data class SetAlarm(val hour: Int, val minute: Int, val label: String) : AuraAction()
    object CheckTimeAndDate : AuraAction()
    data class CheckWeather(val location: String = "Local Area") : AuraAction()
    object CheckBattery : AuraAction()
    object FindMyPhone : AuraAction()
    data class OpenPhoneDialer(val recipient: String) : AuraAction()
    data class ComposeSms(val recipient: String, val message: String) : AuraAction()
    data class OpenSettings(val screenType: String) : AuraAction()
    data class SearchWeb(val query: String) : AuraAction()
    object EmergencyStop : AuraAction()
    data class GeneralSpeechResponse(val replyText: String) : AuraAction()
}
