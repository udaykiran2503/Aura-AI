package com.example.core.services

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class VisibleElement(
    val text: String,
    val viewId: String = "",
    val isClickable: Boolean = false,
    val className: String = ""
)

class AuraAccessibilityService : AccessibilityService() {

    companion object {
        var instance: AuraAccessibilityService? = null
            private set

        private val _isServiceEnabled = MutableStateFlow(false)
        val isServiceEnabled: StateFlow<Boolean> = _isServiceEnabled.asStateFlow()

        private val _lastReadScreenSummary = MutableStateFlow("Accessibility service inactive")
        val lastReadScreenSummary: StateFlow<String> = _lastReadScreenSummary.asStateFlow()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isServiceEnabled.value = true

        val info = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                    AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_SPOKEN
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            notificationTimeout = 100
        }
        serviceInfo = info
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Observes window changes without leaking passwords
    }

    override fun onInterrupt() {
        _isServiceEnabled.value = false
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        _isServiceEnabled.value = false
    }

    /**
     * Inspects active window hierarchy and extracts visible non-sensitive text.
     * Excludes passwords, PINs, and secure text fields.
     */
    fun readCurrentScreenText(): List<VisibleElement> {
        val rootNode = rootInActiveWindow ?: return emptyList()
        val elements = mutableListOf<VisibleElement>()

        fun traverse(node: AccessibilityNodeInfo?) {
            if (node == null) return
            // CRITICAL: Exclude password or secure fields
            if (node.isPassword) return

            val text = node.text?.toString() ?: node.contentDescription?.toString()
            if (!text.isNullOrBlank()) {
                val element = VisibleElement(
                    text = text.trim(),
                    viewId = node.viewIdResourceName ?: "",
                    isClickable = node.isClickable,
                    className = node.className?.toString() ?: ""
                )
                elements.add(element)
            }

            for (i in 0 until node.childCount) {
                traverse(node.getChild(i))
            }
        }

        traverse(rootNode)
        val summary = if (elements.isEmpty()) "No readable text detected on screen."
        else "Read ${elements.size} elements. Top: " + elements.take(3).joinToString("; ") { it.text }
        _lastReadScreenSummary.value = summary

        return elements
    }
}
