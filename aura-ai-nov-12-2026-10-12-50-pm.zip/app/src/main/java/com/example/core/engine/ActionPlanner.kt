package com.example.core.engine

import android.content.Context
import com.example.core.device.DeviceController
import com.example.core.routine.RoutineExecutionState
import com.example.core.routine.RoutineExecutor
import com.example.core.voice.VoiceManager
import com.example.core.voice.VoiceProfileManager
import com.example.data.local.dao.VoiceCommandDao
import com.example.data.local.entity.VoiceCommandEntity
import com.example.data.repository.RoutineRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ActionPlanner(
    private val context: Context,
    private val deviceController: DeviceController,
    private val voiceManager: VoiceManager,
    private val routineRepository: RoutineRepository,
    private val routineExecutor: RoutineExecutor,
    private val voiceProfileManager: VoiceProfileManager,
    private val safetyController: SafetyController,
    private val voiceCommandDao: VoiceCommandDao
) {
    private val _lastExecutionSummary = MutableStateFlow("")
    val lastExecutionSummary: StateFlow<String> = _lastExecutionSummary.asStateFlow()

    private val _routineState = MutableStateFlow(RoutineExecutionState())
    val routineState: StateFlow<RoutineExecutionState> = _routineState.asStateFlow()

    suspend fun planAndExecute(
        parsedIntent: ParsedIntent,
        operatingMode: String = "STANDARD",
        onDirectConfirmationNeeded: (suspend (title: String, details: String, onApproved: suspend () -> Unit) -> Unit)? = null
    ) {
        if (safetyController.isPrivacyModeActive.value) {
            voiceManager.speak("Privacy mode is active. Microphone and automated actions are suspended.")
            return
        }

        // Voice Profile Verification
        val voiceMatch = voiceProfileManager.verifyVoice()

        when (val action = parsedIntent.action) {
            is AuraAction.EmergencyStop -> {
                voiceManager.emergencyStop()
                deviceController.triggerFindPhoneAlert(false)
                safetyController.logEmergencyStop()
                _routineState.value = RoutineExecutionState()
                _lastExecutionSummary.value = "Emergency stop invoked."
                recordCommand(parsedIntent, "Emergency stop executed.", voiceMatch.speakerName, true)
            }

            is AuraAction.ExecuteRoutine -> {
                val routine = routineRepository.getRoutineById(action.routineId)
                if (routine != null) {
                    _lastExecutionSummary.value = "Running routine: ${routine.name}"
                    recordCommand(parsedIntent, "Executing ${routine.name}", voiceMatch.speakerName, voiceMatch.isMatch)
                    routineExecutor.executeRoutine(routine) { progressState ->
                        _routineState.value = progressState
                    }
                } else {
                    val msg = "Routine '${action.routineName}' is not currently available."
                    voiceManager.speak(msg)
                    _lastExecutionSummary.value = msg
                    recordCommand(parsedIntent, msg, voiceMatch.speakerName, voiceMatch.isMatch)
                }
            }

            is AuraAction.ToggleFlashlight -> {
                val (success, msg) = deviceController.toggleFlashlight(action.enable)
                voiceManager.speak(msg)
                _lastExecutionSummary.value = msg
                recordCommand(parsedIntent, msg, voiceMatch.speakerName, voiceMatch.isMatch)
            }

            is AuraAction.AdjustVolume -> {
                val (success, msg) = deviceController.setVolumePercent(action.percent)
                voiceManager.speak(msg)
                _lastExecutionSummary.value = msg
                recordCommand(parsedIntent, msg, voiceMatch.speakerName, voiceMatch.isMatch)
            }

            is AuraAction.CheckTimeAndDate -> {
                val timeStr = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
                val dateStr = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date())
                val reply = "It is currently $timeStr on $dateStr."
                voiceManager.speak(reply)
                _lastExecutionSummary.value = reply
                recordCommand(parsedIntent, reply, voiceMatch.speakerName, voiceMatch.isMatch)
            }

            is AuraAction.CheckWeather -> {
                val reply = "Weather in ${action.location}: 28 degrees Celsius, mostly sunny with light wind."
                voiceManager.speak(reply)
                _lastExecutionSummary.value = reply
                recordCommand(parsedIntent, reply, voiceMatch.speakerName, voiceMatch.isMatch)
            }

            is AuraAction.CheckBattery -> {
                val (success, msg) = Pair(true, "Battery level detected.")
                val bm = context.getSystemService(Context.BATTERY_SERVICE) as? android.os.BatteryManager
                val pct = bm?.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 80
                val reply = "Battery is at $pct percent."
                voiceManager.speak(reply)
                _lastExecutionSummary.value = reply
                recordCommand(parsedIntent, reply, voiceMatch.speakerName, voiceMatch.isMatch)
            }

            is AuraAction.FindMyPhone -> {
                voiceManager.speak("Sounding locator alert.")
                deviceController.triggerFindPhoneAlert(true)
                _lastExecutionSummary.value = "Audible siren alert sounding."
                recordCommand(parsedIntent, "Audible locator alert triggered.", voiceMatch.speakerName, voiceMatch.isMatch)
            }

            is AuraAction.OpenApp -> {
                val (success, msg) = deviceController.launchAppByNameOrPackage(action.appQuery)
                voiceManager.speak(msg)
                _lastExecutionSummary.value = msg
                recordCommand(parsedIntent, msg, voiceMatch.speakerName, voiceMatch.isMatch)
            }

            is AuraAction.SetAlarm -> {
                val (success, msg) = deviceController.setAlarm(action.hour, action.minute, action.label)
                voiceManager.speak(msg)
                _lastExecutionSummary.value = msg
                recordCommand(parsedIntent, msg, voiceMatch.speakerName, voiceMatch.isMatch)
            }

            is AuraAction.OpenPhoneDialer -> {
                // Sensitive Action: requires confirmation and device auth check
                val promptTitle = "Confirm Phone Call"
                val promptDetails = "Call request to '${action.recipient}'. Sensitive telephony operation requires approval."
                if (voiceMatch.requiresDeviceAuth) {
                    safetyController.requestConfirmation(
                        title = promptTitle,
                        details = promptDetails,
                        actionType = "CALL_PHONE",
                        requiresDeviceAuth = true,
                        onConfirm = {
                            val (success, msg) = deviceController.openDialer(action.recipient)
                            voiceManager.speak("Dialing ${action.recipient}.")
                            _lastExecutionSummary.value = msg
                        }
                    )
                } else {
                    val (success, msg) = deviceController.openDialer(action.recipient)
                    voiceManager.speak("Dialing ${action.recipient}.")
                    _lastExecutionSummary.value = msg
                }
            }

            is AuraAction.ComposeSms -> {
                val (success, msg) = deviceController.openSmsComposer(action.recipient, action.message)
                voiceManager.speak("Drafted SMS to ${action.recipient}.")
                _lastExecutionSummary.value = msg
                recordCommand(parsedIntent, msg, voiceMatch.speakerName, voiceMatch.isMatch)
            }

            is AuraAction.OpenSettings -> {
                val (success, msg) = deviceController.openSettingsScreen(action.screenType)
                voiceManager.speak(msg)
                _lastExecutionSummary.value = msg
                recordCommand(parsedIntent, msg, voiceMatch.speakerName, voiceMatch.isMatch)
            }

            is AuraAction.SearchWeb -> {
                val (success, msg) = deviceController.openWebsiteOrSearch(action.query)
                voiceManager.speak(msg)
                _lastExecutionSummary.value = msg
                recordCommand(parsedIntent, msg, voiceMatch.speakerName, voiceMatch.isMatch)
            }

            is AuraAction.GeneralSpeechResponse -> {
                voiceManager.speak(action.replyText)
                _lastExecutionSummary.value = action.replyText
                recordCommand(parsedIntent, action.replyText, voiceMatch.speakerName, voiceMatch.isMatch)
            }
        }
    }

    private suspend fun recordCommand(
        parsedIntent: ParsedIntent,
        response: String,
        speakerName: String,
        isVerified: Boolean
    ) {
        try {
            voiceCommandDao.insertCommand(
                VoiceCommandEntity(
                    commandText = parsedIntent.rawText,
                    interpretedIntent = parsedIntent.intentName,
                    status = "SUCCESS",
                    responseSpoken = response,
                    speakerVerified = isVerified,
                    speakerName = speakerName,
                    timestamp = System.currentTimeMillis()
                )
            )
        } catch (e: Exception) {
            // ignore logging error
        }
    }
}
