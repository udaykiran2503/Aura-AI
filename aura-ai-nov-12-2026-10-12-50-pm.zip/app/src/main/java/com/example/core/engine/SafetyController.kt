package com.example.core.engine

import com.example.data.local.dao.SecurityLogDao
import com.example.data.local.entity.SecurityLogEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SafetyController(private val securityLogDao: SecurityLogDao) {

    private val _isPrivacyModeActive = MutableStateFlow(false)
    val isPrivacyModeActive: StateFlow<Boolean> = _isPrivacyModeActive.asStateFlow()

    private val _pendingConfirmationAction = MutableStateFlow<PendingConfirmation?>(null)
    val pendingConfirmationAction: StateFlow<PendingConfirmation?> = _pendingConfirmationAction.asStateFlow()

    data class PendingConfirmation(
        val title: String,
        val details: String,
        val actionType: String,
        val requiresDeviceAuth: Boolean = false,
        val onConfirm: () -> Unit,
        val onCancel: () -> Unit
    )

    fun togglePrivacyMode(enabled: Boolean) {
        _isPrivacyModeActive.value = enabled
    }

    suspend fun requestConfirmation(
        title: String,
        details: String,
        actionType: String,
        requiresDeviceAuth: Boolean,
        onConfirm: () -> Unit,
        onCancel: () -> Unit = {}
    ) {
        securityLogDao.insertLog(
            SecurityLogEntity(
                eventType = "SENSITIVE_CONFIRMATION",
                title = "Confirmation Prompt: $title",
                details = details,
                riskLevel = "WARNING"
            )
        )
        _pendingConfirmationAction.value = PendingConfirmation(
            title = title,
            details = details,
            actionType = actionType,
            requiresDeviceAuth = requiresDeviceAuth,
            onConfirm = {
                _pendingConfirmationAction.value = null
                onConfirm()
            },
            onCancel = {
                _pendingConfirmationAction.value = null
                onCancel()
            }
        )
    }

    fun dismissConfirmation() {
        _pendingConfirmationAction.value?.onCancel?.invoke()
        _pendingConfirmationAction.value = null
    }

    suspend fun logEmergencyStop() {
        securityLogDao.insertLog(
            SecurityLogEntity(
                eventType = "EMERGENCY_STOP",
                title = "Emergency Stop Invoked",
                details = "User halted all voice execution and active routines immediately.",
                riskLevel = "CRITICAL"
            )
        )
    }
}
