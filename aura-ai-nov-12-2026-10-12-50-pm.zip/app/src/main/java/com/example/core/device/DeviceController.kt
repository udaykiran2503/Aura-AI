package com.example.core.device

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.Settings
import android.util.Log

class DeviceController(private val context: Context) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager

    private var isTorchOn = false
    private var isSirenPlaying = false
    private var activeRingtone: android.media.Ringtone? = null

    // 1. App Launching
    fun launchAppByNameOrPackage(query: String): Pair<Boolean, String> {
        val q = query.trim().lowercase()
        val pm = context.packageManager

        // Check common mapped apps
        val targetPackage = when {
            q.contains("whatsapp") -> "com.whatsapp"
            q.contains("youtube") -> "com.google.android.youtube"
            q.contains("map") -> "com.google.android.apps.maps"
            q.contains("chrome") || q.contains("browser") -> "com.android.chrome"
            q.contains("calc") -> "com.google.android.calculator"
            q.contains("clock") || q.contains("alarm") -> "com.google.android.deskclock"
            q.contains("camera") -> {
                val intent = Intent("android.media.action.IMAGE_CAPTURE").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (intent.resolveActivity(pm) != null) {
                    context.startActivity(intent)
                    return Pair(true, "Camera opened.")
                }
                null
            }
            q.contains("setting") -> {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return Pair(true, "Settings opened.")
            }
            else -> null
        }

        if (targetPackage != null) {
            val intent = pm.getLaunchIntentForPackage(targetPackage)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return Pair(true, "Opening application.")
            }
        }

        // Try searching installed applications
        try {
            val installedApps = pm.getInstalledApplications(0)
            for (app in installedApps) {
                val label = pm.getApplicationLabel(app).toString().lowercase()
                if (label.contains(q) || app.packageName.lowercase().contains(q)) {
                    val intent = pm.getLaunchIntentForPackage(app.packageName)
                    if (intent != null) {
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(intent)
                        return Pair(true, "Opening $label.")
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("DeviceController", "App launch error", e)
        }

        return Pair(false, "Could not locate an application matching '$query'.")
    }

    // 2. Flashlight
    fun toggleFlashlight(turnOn: Boolean): Pair<Boolean, String> {
        return try {
            val cameraIds = cameraManager?.cameraIdList ?: emptyArray()
            var torchCameraId: String? = null
            for (id in cameraIds) {
                val chars = cameraManager?.getCameraCharacteristics(id)
                val hasFlash = chars?.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                val facing = chars?.get(CameraCharacteristics.LENS_FACING)
                if (hasFlash && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    torchCameraId = id
                    break
                }
            }
            if (torchCameraId != null) {
                cameraManager?.setTorchMode(torchCameraId, turnOn)
                isTorchOn = turnOn
                Pair(true, if (turnOn) "Flashlight turned on." else "Flashlight turned off.")
            } else {
                Pair(false, "Flashlight hardware not available on this camera.")
            }
        } catch (e: Exception) {
            Pair(false, "Flashlight control error: ${e.message}")
        }
    }

    // 3. Volume
    fun setVolumePercent(percent: Int, streamType: Int = AudioManager.STREAM_MUSIC): Pair<Boolean, String> {
        return try {
            val maxVol = audioManager?.getStreamMaxVolume(streamType) ?: 15
            val clamped = percent.coerceIn(0, 100)
            val targetLevel = (maxVol * (clamped / 100.0f)).toInt()
            audioManager?.setStreamVolume(streamType, targetLevel, AudioManager.FLAG_SHOW_UI)
            Pair(true, "Volume set to $clamped%.")
        } catch (e: Exception) {
            Pair(false, "Failed to adjust volume: ${e.message}")
        }
    }

    // 4. Alarms
    fun setAlarm(hour: Int, minute: Int, message: String): Pair<Boolean, String> {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, message)
                putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Pair(true, "Alarm scheduled for %02d:%02d.".format(hour, minute))
        } catch (e: Exception) {
            Pair(false, "Unable to set alarm automatically: ${e.message}")
        }
    }

    // 5. Phone Call / Dial
    fun openDialer(phoneNumber: String): Pair<Boolean, String> {
        return try {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:$phoneNumber")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Pair(true, "Dialer opened for $phoneNumber.")
        } catch (e: Exception) {
            Pair(false, "Dialer launch failed: ${e.message}")
        }
    }

    // 6. Send SMS
    fun openSmsComposer(phoneNumber: String, messageText: String): Pair<Boolean, String> {
        return try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("smsto:$phoneNumber")
                putExtra("sms_body", messageText)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Pair(true, "SMS drafted to $phoneNumber.")
        } catch (e: Exception) {
            Pair(false, "SMS composer launch failed: ${e.message}")
        }
    }

    // 7. Find My Phone (Audible Siren Alert)
    fun triggerFindPhoneAlert(play: Boolean): Pair<Boolean, String> {
        return try {
            if (play) {
                // Maximize alarm volume
                audioManager?.let { am ->
                    val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
                    am.setStreamVolume(AudioManager.STREAM_ALARM, maxVol, 0)
                }
                val alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                activeRingtone?.stop()
                activeRingtone = RingtoneManager.getRingtone(context, alarmUri).apply {
                    audioAttributes = AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                    play()
                }
                isSirenPlaying = true
                Pair(true, "Audible locator siren sounding at maximum volume.")
            } else {
                activeRingtone?.stop()
                activeRingtone = null
                isSirenPlaying = false
                Pair(true, "Locator siren stopped.")
            }
        } catch (e: Exception) {
            Pair(false, "Alert sound error: ${e.message}")
        }
    }

    // 8. Open Website / Web Search
    fun openWebsiteOrSearch(queryOrUrl: String): Pair<Boolean, String> {
        return try {
            val url = if (queryOrUrl.startsWith("http://") || queryOrUrl.startsWith("https://")) {
                queryOrUrl
            } else {
                "https://www.google.com/search?q=${Uri.encode(queryOrUrl)}"
            }
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Pair(true, "Opening browser for '$queryOrUrl'.")
        } catch (e: Exception) {
            Pair(false, "Browser error: ${e.message}")
        }
    }

    // 9. Open Android Settings Screen
    fun openSettingsScreen(type: String): Pair<Boolean, String> {
        val action = when (type.lowercase()) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        return try {
            val intent = Intent(action).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Pair(true, "Opened $type settings.")
        } catch (e: Exception) {
            Pair(false, "Could not open $type settings: ${e.message}")
        }
    }

    fun isSirenActive(): Boolean = isSirenPlaying
    fun isFlashlightOn(): Boolean = isTorchOn
}
