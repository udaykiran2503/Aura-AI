package com.example.core.hardware

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.speech.SpeechRecognizer
import java.io.File

enum class OperatingMode(val title: String, val subtitle: String) {
    LIGHT(
        "Light Mode",
        "Optimized for budget/older phones. Low memory footprint, fast offline rule-based reasoning, reduced animations."
    ),
    STANDARD(
        "Standard Mode",
        "Balanced for mid-range smartphones. Enhanced speech processing, full app automation, and context awareness."
    ),
    ADVANCED(
        "Advanced Mode",
        "High-performance mode. Complex multi-step task planning, screen understanding, and full predictive intelligence."
    )
}

enum class FeatureStatus(val label: String) {
    SUPPORTED("Supported"),
    REQUIRES_PERMISSION("Requires Permission"),
    MANUFACTURER_LIMITED("Limited by Manufacturer"),
    NOT_SUPPORTED("Not Supported")
}

data class CapabilityItem(
    val featureName: String,
    val status: FeatureStatus,
    val details: String,
    val category: String
)

data class DeviceSpecs(
    val manufacturer: String,
    val model: String,
    val androidVersion: String,
    val apiLevel: Int,
    val cpuArch: String,
    val totalRamMb: Long,
    val availableRamMb: Long,
    val totalStorageGb: Long,
    val availableStorageGb: Long,
    val batteryPercent: Int,
    val isCharging: Boolean,
    val networkType: String,
    val hasSpeechRecognizer: Boolean,
    val recommendedMode: OperatingMode
)

class DeviceCompatibilityManager(private val context: Context) {

    fun getDeviceSpecs(): DeviceSpecs {
        val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        actManager?.getMemoryInfo(memInfo)

        val totalRamMb = memInfo.totalMem / (1024 * 1024)
        val availRamMb = memInfo.availMem / (1024 * 1024)

        // Storage
        val statFs = StatFs(Environment.getDataDirectory().path)
        val totalStorageGb = (statFs.blockSizeLong * statFs.blockCountLong) / (1024 * 1024 * 1024)
        val availStorageGb = (statFs.blockSizeLong * statFs.availableBlocksLong) / (1024 * 1024 * 1024)

        // Battery
        val batteryStatus: Intent? = IntentFilter(Intent.ACTION_BATTERY_CHANGED).let { filter ->
            context.registerReceiver(null, filter)
        }
        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val batteryPct = if (level >= 0 && scale > 0) (level * 100 / scale) else 75
        val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

        // Network
        val connMgr = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val networkCaps = connMgr?.getNetworkCapabilities(connMgr.activeNetwork)
        val netType = when {
            networkCaps == null -> "Offline"
            networkCaps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            networkCaps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cellular (Mobile Data)"
            else -> "Connected"
        }

        val speechAvailable = SpeechRecognizer.isRecognitionAvailable(context)

        // Calculate Recommended Mode based on hardware detection
        // Light: RAM <= 3GB or Low Ram Device or API < 28
        // Advanced: RAM >= 6GB, API >= 31
        val recommendedMode = when {
            memInfo.lowMemory || totalRamMb <= 3200 || Build.VERSION.SDK_INT < 28 -> OperatingMode.LIGHT
            totalRamMb >= 6000 && Build.VERSION.SDK_INT >= 30 -> OperatingMode.ADVANCED
            else -> OperatingMode.STANDARD
        }

        return DeviceSpecs(
            manufacturer = Build.MANUFACTURER.replaceFirstChar { it.uppercase() },
            model = Build.MODEL,
            androidVersion = Build.VERSION.RELEASE,
            apiLevel = Build.VERSION.SDK_INT,
            cpuArch = Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a",
            totalRamMb = totalRamMb,
            availableRamMb = availRamMb,
            totalStorageGb = totalStorageGb,
            availableStorageGb = availStorageGb,
            batteryPercent = batteryPct,
            isCharging = isCharging,
            networkType = netType,
            hasSpeechRecognizer = speechAvailable,
            recommendedMode = recommendedMode
        )
    }

    fun getCapabilitiesMatrix(): List<CapabilityItem> {
        val specs = getDeviceSpecs()
        val list = mutableListOf<CapabilityItem>()

        // Speech Recognition
        list.add(
            CapabilityItem(
                featureName = "Voice Speech Recognition",
                status = if (specs.hasSpeechRecognizer) FeatureStatus.SUPPORTED else FeatureStatus.NOT_SUPPORTED,
                details = if (specs.hasSpeechRecognizer) "Android SpeechRecognizer engine available" else "No speech engine installed on this device",
                category = "Voice Engine"
            )
        )

        // Offline Intent Parser
        list.add(
            CapabilityItem(
                featureName = "Offline Voice Brain",
                status = FeatureStatus.SUPPORTED,
                details = "Local regex & rule-based natural language intent parser for zero-data operation",
                category = "Voice Engine"
            )
        )

        // Wake Word Detection
        list.add(
            CapabilityItem(
                featureName = "Custom Wake Word (Hey Aura)",
                status = FeatureStatus.SUPPORTED,
                details = "Configurable wake word with foreground microphone service",
                category = "Voice Engine"
            )
        )

        // Text-to-Speech
        list.add(
            CapabilityItem(
                featureName = "Multilingual Text-to-Speech",
                status = FeatureStatus.SUPPORTED,
                details = "Supports English, Telugu, Hindi, Tamil, Kannada voice synthesis",
                category = "Voice Engine"
            )
        )

        // Flashlight Torch
        list.add(
            CapabilityItem(
                featureName = "Flashlight / Torch Control",
                status = FeatureStatus.SUPPORTED,
                details = "CameraManager hardware torch toggle with auto-off safety",
                category = "Hardware Control"
            )
        )

        // Volume & Media
        list.add(
            CapabilityItem(
                featureName = "Volume & Media Controller",
                status = FeatureStatus.SUPPORTED,
                details = "Direct stream volume adjustment (Media, Ring, Alarm) & MediaSession keys",
                category = "Hardware Control"
            )
        )

        // App Launching
        list.add(
            CapabilityItem(
                featureName = "Application Launcher",
                status = FeatureStatus.SUPPORTED,
                details = "Launches WhatsApp, Maps, Camera, YouTube, Browser, Settings via standard Intents",
                category = "System Operations"
            )
        )

        // Calling & SMS
        list.add(
            CapabilityItem(
                featureName = "Phone Calls & SMS Messaging",
                status = FeatureStatus.REQUIRES_PERMISSION,
                details = "Requires runtime CALL_PHONE and SEND_SMS permission plus user confirmation",
                category = "Telephony"
            )
        )

        // Contacts Access
        list.add(
            CapabilityItem(
                featureName = "Contacts Search",
                status = FeatureStatus.REQUIRES_PERMISSION,
                details = "Reads phonebook contacts to resolve names to dial or message",
                category = "Telephony"
            )
        )

        // Alarms & Clocks
        list.add(
            CapabilityItem(
                featureName = "Alarm & Reminder Scheduling",
                status = FeatureStatus.SUPPORTED,
                details = "Sets system clock alarms and reminders via AlarmClock intents",
                category = "System Operations"
            )
        )

        // Screen Understanding & Accessibility
        list.add(
            CapabilityItem(
                featureName = "Hands-Free Screen Reading",
                status = FeatureStatus.REQUIRES_PERMISSION,
                details = "Requires explicit user enablement in Android Accessibility Settings",
                category = "Accessibility"
            )
        )

        // Aggressive OEM Background Killers (Xiaomi, Vivo, Oppo, Samsung)
        val oem = Build.MANUFACTURER.lowercase()
        val isAggressiveOem = oem.contains("xiaomi") || oem.contains("redmi") ||
                oem.contains("oppo") || oem.contains("vivo") || oem.contains("realme")
        list.add(
            CapabilityItem(
                featureName = "Continuous Background Listening",
                status = if (isAggressiveOem) FeatureStatus.MANUFACTURER_LIMITED else FeatureStatus.SUPPORTED,
                details = if (isAggressiveOem) "${specs.manufacturer} aggressively terminates background services. Disable battery optimization in settings." else "Supported with Android foreground service notification.",
                category = "Background Execution"
            )
        )

        return list
    }
}
