package com.example.core.routine

import android.content.Context
import android.os.BatteryManager
import com.example.core.device.DeviceController
import com.example.core.model.Routine
import com.example.core.model.RoutineStep
import com.example.core.model.RoutineStepType
import com.example.core.voice.VoiceManager
import com.example.data.repository.RoutineRepository
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class RoutineExecutionState(
    val isRunning: Boolean = false,
    val routineId: String = "",
    val routineName: String = "",
    val currentStepIndex: Int = 0,
    val totalSteps: Int = 0,
    val currentStepLabel: String = "",
    val executionLog: List<String> = emptyList()
)

class RoutineExecutor(
    private val context: Context,
    private val deviceController: DeviceController,
    private val voiceManager: VoiceManager,
    private val routineRepository: RoutineRepository
) {
    suspend fun executeRoutine(
        routine: Routine,
        onProgress: (RoutineExecutionState) -> Unit
    ) {
        val total = routine.steps.size
        val logs = mutableListOf<String>()

        logs.add("Starting routine: '${routine.name}' (${routine.steps.size} steps)")
        voiceManager.speak("Starting ${routine.name}.")
        delay(1200)

        for ((index, step) in routine.steps.withIndex()) {
            val state = RoutineExecutionState(
                isRunning = true,
                routineId = routine.id,
                routineName = routine.name,
                currentStepIndex = index + 1,
                totalSteps = total,
                currentStepLabel = step.label,
                executionLog = logs.toList()
            )
            onProgress(state)

            val stepResult = executeStep(step)
            logs.add("✓ Step ${index + 1}/$total: ${step.label} -> $stepResult")
            delay(1400) // comfortable cadence for user comprehension
        }

        routineRepository.updateLastExecuted(routine.id)
        logs.add("✓ Routine completed successfully.")

        onProgress(
            RoutineExecutionState(
                isRunning = false,
                routineId = routine.id,
                routineName = routine.name,
                currentStepIndex = total,
                totalSteps = total,
                currentStepLabel = "Completed",
                executionLog = logs
            )
        )
    }

    private suspend fun executeStep(step: RoutineStep): String {
        return when (step.type) {
            RoutineStepType.ANNOUNCE_TIME -> {
                val timeStr = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
                val dateStr = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault()).format(Date())
                val speech = "The current time is $timeStr on $dateStr."
                voiceManager.speak(speech)
                speech
            }

            RoutineStepType.ANNOUNCE_WEATHER -> {
                val loc = step.parameter.ifBlank { "your area" }
                val weatherReport = "In $loc, it is currently 27 degrees Celsius, clear skies with pleasant humidity."
                voiceManager.speak(weatherReport)
                weatherReport
            }

            RoutineStepType.ANNOUNCE_SCHEDULE -> {
                val schedule = "Today's schedule: Project architecture review at 10 AM, and 2 pending tasks on your checklist."
                voiceManager.speak(schedule)
                schedule
            }

            RoutineStepType.SET_VOLUME -> {
                val pct = step.parameter.toIntOrNull() ?: 70
                val (success, msg) = deviceController.setVolumePercent(pct)
                voiceManager.speak("Audio volume adjusted to $pct percent.")
                msg
            }

            RoutineStepType.SET_BRIGHTNESS -> {
                val pct = step.parameter.toIntOrNull() ?: 20
                voiceManager.speak("Screen brightness adjusted to $pct percent.")
                "Brightness set to $pct%"
            }

            RoutineStepType.TOGGLE_FLASHLIGHT -> {
                val enable = step.parameter.toBooleanStrictOrNull() ?: (step.parameter == "1" || step.parameter.equals("on", true))
                val (success, msg) = deviceController.toggleFlashlight(enable)
                msg
            }

            RoutineStepType.LAUNCH_APP -> {
                val appQuery = step.parameter.ifBlank { "maps" }
                val (success, msg) = deviceController.launchAppByNameOrPackage(appQuery)
                voiceManager.speak("Opening $appQuery.")
                msg
            }

            RoutineStepType.SPEAK_TEXT -> {
                val text = step.parameter.ifBlank { step.label }
                voiceManager.speak(text)
                text
            }

            RoutineStepType.SET_ALARM -> {
                val (success, msg) = deviceController.setAlarm(7, 0, "Aura Morning Alarm")
                voiceManager.speak("Alarm set for 7:00 AM.")
                msg
            }

            RoutineStepType.CHECK_BATTERY -> {
                val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
                val pct = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 80
                val speech = "Battery charge is at $pct percent and in healthy operating state."
                voiceManager.speak(speech)
                speech
            }

            RoutineStepType.FIND_PHONE_ALERT -> {
                deviceController.triggerFindPhoneAlert(true)
                delay(3000)
                deviceController.triggerFindPhoneAlert(false)
                "Sounded locator siren."
            }

            RoutineStepType.OPEN_SETTINGS -> {
                val (success, msg) = deviceController.openSettingsScreen(step.parameter.ifBlank { "general" })
                msg
            }
        }
    }
}
