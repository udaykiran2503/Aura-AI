package com.example

import com.example.core.engine.AuraAction
import com.example.core.engine.IntentParser
import com.example.core.model.Routine
import com.example.core.model.RoutineStep
import com.example.core.model.RoutineStepType
import com.example.data.repository.toDomain
import com.example.data.repository.toEntity
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleUnitTest {

    @Test
    fun testRoutineSerialization() {
        val routine = Routine(
            id = "test_routine",
            name = "Test Routine",
            triggerPhrase = "test now",
            description = "A test routine",
            iconName = "wb_sunny",
            isEnabled = true,
            isCustom = true,
            steps = listOf(
                RoutineStep("s1", RoutineStepType.ANNOUNCE_TIME, "Announce Time"),
                RoutineStep("s2", RoutineStepType.ANNOUNCE_WEATHER, "Weather", "Dallas"),
                RoutineStep("s3", RoutineStepType.SET_VOLUME, "Volume 50%", "50")
            )
        )

        val entity = routine.toEntity()
        val restored = entity.toDomain()

        assertEquals(routine.id, restored.id)
        assertEquals(routine.name, restored.name)
        assertEquals(routine.triggerPhrase, restored.triggerPhrase)
        assertEquals(3, restored.steps.size)
        assertEquals(RoutineStepType.ANNOUNCE_TIME, restored.steps[0].type)
        assertEquals("Dallas", restored.steps[1].parameter)
        assertEquals("50", restored.steps[2].parameter)
    }

    @Test
    fun testIntentParserKeywords() = runBlocking {
        val dummyDao = object : com.example.data.local.dao.RoutineDao {
            override fun getAllRoutines() = kotlinx.coroutines.flow.flowOf(emptyList<com.example.data.local.entity.RoutineEntity>())
            override fun getActiveRoutines() = kotlinx.coroutines.flow.flowOf(emptyList<com.example.data.local.entity.RoutineEntity>())
            override suspend fun getRoutineById(id: String) = null
            override suspend fun getActiveRoutinesSync() = emptyList<com.example.data.local.entity.RoutineEntity>()
            override suspend fun insertRoutine(routine: com.example.data.local.entity.RoutineEntity) {}
            override suspend fun insertRoutines(routines: List<com.example.data.local.entity.RoutineEntity>) {}
            override suspend fun updateRoutine(routine: com.example.data.local.entity.RoutineEntity) {}
            override suspend fun setRoutineEnabled(id: String, isEnabled: Boolean) {}
            override suspend fun updateLastExecuted(id: String, timestamp: Long) {}
            override suspend fun deleteRoutineById(id: String) {}
            override suspend fun getCount() = 0
        }
        val parser = IntentParser(com.example.data.repository.RoutineRepository(dummyDao))

        // Good Morning routine intent
        val gmIntent = parser.parse("Hey Aura, good morning")
        assertEquals("EXECUTE_ROUTINE", gmIntent.intentName)
        assertTrue(gmIntent.action is AuraAction.ExecuteRoutine)
        assertEquals("good_morning", (gmIntent.action as AuraAction.ExecuteRoutine).routineId)

        // Flashlight intent
        val torchIntent = parser.parse("turn on flashlight")
        assertEquals("TOGGLE_FLASHLIGHT", torchIntent.intentName)
        assertTrue((torchIntent.action as AuraAction.ToggleFlashlight).enable)

        // Find my phone intent
        val findPhone = parser.parse("where is my phone")
        assertEquals("FIND_MY_PHONE", findPhone.intentName)

        // Stop command
        val stop = parser.parse("stop")
        assertEquals("EMERGENCY_STOP", stop.intentName)
    }
}
